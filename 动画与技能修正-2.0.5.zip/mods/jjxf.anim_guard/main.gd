extends Node

# 精简补丁包，只保留两件事：
#   1) 普攻取消守卫：真技能进行中按 X 不会被顶成普攻 / 近战三连；
#      普攻本体、三段、冲刺攻击、三段后的特殊攻击全部放行。
#   2) configure 修复：动作播放期间不重建部件，
#      覆盖 Game.equipment_changed（含宠物自动嗑血药触发的写入）与时装隐藏的直接调用。
# 不含任何探针、截图、逐帧日志。

func install(_api) -> bool:
	return true

func on_game_ready(_api) -> bool:
	return true

func verify(_api) -> Dictionary:
	return {"ok": true}
