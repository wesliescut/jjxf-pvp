shader_type canvas_item;
render_mode unshaded;

// 霸体光晕：在原像素外圈叠一层黄色轮廓光，本体颜色保持不变。
// 不使用除法、alpha 始终 clamp 到 1，因此不会出现发黑的边缘。

uniform vec4 glow_color : source_color = vec4(1.0, 0.82, 0.2, 1.0);
uniform float radius : hint_range(1.0, 8.0) = 3.0;
uniform float strength : hint_range(0.0, 2.0) = 1.0;
uniform float body_boost : hint_range(0.0, 1.0) = 0.35;

void fragment() {
	vec4 body = texture(TEXTURE, UV);
	float blurred = 0.0;
	for (int y = -2; y <= 2; y++) {
		for (int x = -2; x <= 2; x++) {
			vec2 offset = vec2(float(x), float(y)) * radius * TEXTURE_PIXEL_SIZE;
			blurred += texture(TEXTURE, UV + offset).a / 25.0;
		}
	}
	float halo = clamp(blurred * 2.0 - body.a, 0.0, 1.0) * strength;
	float boost = body.a * body_boost * strength;
	vec3 rgb = mix(body.rgb, glow_color.rgb, clamp(halo + boost, 0.0, 1.0));
	float alpha = clamp(body.a + halo, 0.0, 1.0);
	COLOR = vec4(rgb, alpha) * COLOR;
}
