extends RefCounted

const DAMAGE_ARMOR_STATUS: String = "9900701"

const PATH: String = "res://data/block_rules.json"
static var _rules: Dictionary = {}
static var _loaded: bool = false

static func _table() -> Dictionary:
	if not _loaded:
		_loaded = true
		if FileAccess.file_exists(PATH):
			var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
			if parsed is Dictionary:
				_rules = parsed
	return _rules

static func _has_value(values, wanted: int) -> bool:
	if values is Array:
		for value in values:
			if int(value) == wanted:
				return true
	return false

static func active_action(run) -> int:
	if run == null or int(run.get("current_skill")) == 0:
		return 0
	var player = run.get("action_player")
	if player == null or not player.active:
		return 0
	return int(player.action_id)

static func blocking(run) -> bool:
	# Scope the guard to the live action. A leftover motion or reduction value
	# must not protect unrelated actions after block ends.
	var action: int = active_action(run)
	if action == 0:
		return false
	var rules: Dictionary = _table()
	if not _has_value(rules.get("careers", [100]), int(Game.base_career())):
		return false
	return _has_value(rules.get("actions", [106]), action)

static func armor_active(run) -> bool:
	if run != null and run.source_status.active.has(DAMAGE_ARMOR_STATUS):
		return true
	if int(Game.base_career())==500 and active_action(run) in [502,506,507]:return true
	if awakening_active(run):return true
	if preload("res://scripts/skill_steer.gd").phoenix_armor(run):return true
	if branch_armor(run):
		return true
	if blocking(run):
		return true
	# All nine states of GF's awakening share action 149. The action lifetime,
	# rather than a timed status or individual animation frame, owns the armor.
	var action: int = active_action(run)
	var career: int = int(Game.role().get("career", 0))
	if action == 149 and career == 120:
		return true
	if int(Game.base_career()) == 200:
		return action == 206 or (career == 220 and action == 257)
	if int(Game.base_career()) != 300:
		return false
	if action in [302, 304]:
		return true
	return career == 310 and action in [308, 315, 310, 312, 344]

static func reduction() -> float:
	return float(_table().get("damage_reduction", 0.6))

static func refresh(run) -> void:
	if run == null:
		return
	if blocking(run):
		run.blocking_rate = reduction()
	elif int(run.get("current_skill")) == 0 and float(run.get("blocking_rate")) > 0.0:
		run.blocking_rate = 0.0

# Sustained fire ignores normal hurt and horizontal knockback, but deliberately
# leaves native launch reactions enabled. This is distinct from full armor.
static func sustained_fire_active(run) -> bool:
	var action: int = active_action(run)
	if int(Game.base_career()) != 200 or action == 0:
		return false
	if action == 204:
		return true
	return int(Game.role().get("career", 0)) == 220 and action in [212, 231, 253, 229, 228]

static func launch_hit(run, hit: Dictionary) -> bool:
	var airborne: bool = run.player.jump_height > 0
	return int(hit.get("air_power_y" if airborne else "power_y", 0)) > 0

static func protects_hit(run, hit: Dictionary) -> bool:
	return invulnerable_active(run) or armor_active(run) or (sustained_fire_active(run) and not launch_hit(run, hit))


# Branch protection is owned by an active action, including its opening frame.
static func branch_armor(run) -> bool:
	if run == null:
		return false
	var career: int = int(Game.role().get("career", 0))
	if career == 330 and run.source_status.active.has("90001"):
		return true # The original ten-second 勇往直前 buff.
	var action: int = active_action(run)
	if career == 320:
		return action in [317, 349, 352]
	if career == 330:
		return action in [326, 346]
	if career == 210:
		return action in [250, 215, 256]
	return false

static func begin_branch(run, index: int) -> void:
	if index == 0 and active_action(run) == 258 and int(Game.role().get("career", 0)) == 230:
		run.set_meta("branch_warp_start", int(run.ticks))

static func invulnerable_active(run) -> bool:
	var action: int = active_action(run)
	if action == 0:
		return false
	var career: int = int(Game.role().get("career", 0))
	if int(Game.base_career()) == 500:
		return action == 509
	if career == 110:
		return action == 148
	if career == 130:
		return action in [133, 150]
	if career == 330:
		# Includes inherited flying knee, every grab, and 抓轰炮's fallback.
		return action in [300, 326, 327, 328, 329, 330, 333, 335, 338, 347, 350, 353]
	if career == 230 and action == 258:
		return int(run.ticks) - int(run.get_meta("branch_warp_start", -100000)) < 30
	return false

static func apply_branches(combat: Dictionary) -> int:
	var changed: int = 0
	for id in combat.catalog:
		var spec: Dictionary = combat.catalog[id]
		if int(spec.get("action", 0)) == 242 and int(spec.get("career", 0)) == 230:
			var fields: Array = combat.fields[id].duplicate(true)
			for field in fields:
				field["damage_only"] = true
			combat.fields[id] = fields
			changed += 1
	return changed

static func awakening_active(run) -> bool:
	var action: int=active_action(run)
	if action==0:return false
	for actions in Game.awakening.get("groups",{}).values():
		if _has_value(actions,action):return true
	return false
