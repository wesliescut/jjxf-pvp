extends RefCounted

# 断空斩（动作 114）四段突进的方向控制：
# 按住 ↑/↓ 时改为纵深位移（z），按住 ←/→ 时改为横向并翻转朝向，
# 不按方向键时保持原本的向前突进。

const ACTION: int = 114
const KEY_UP: int = 0
const KEY_DOWN: int = 1
const KEY_LEFT: int = 2
const KEY_RIGHT: int = 3


static func adjust(run, motion_id: int, args: Dictionary) -> Dictionary:
	if tongling_action(run) == 138 and run.has_meta(TONGLING_MAGNETIC):
		return magnetic_adjust(run, args)
	if run == null:
		return args
	var player_action = run.action_player
	if player_action == null or not player_action.active:
		return args
	if int(player_action.action_id) == 316 and int(Game.role().get("career", 0)) == 310:
		var out: Dictionary = args.duplicate()
		out["x"] = 0
		out["walkV"] = 0
		out["useLastestVX"] = 0
		out["useCurrentVX"] = 0
		return out
	if int(player_action.action_id) != ACTION or int(Game.role().get("career", 0)) != 110:
		return args
	var speed: int = int(args.get("x", 0))
	if speed == 0:
		return args
	var held: Dictionary = player_action.held
	var up: bool = bool(held.get(KEY_UP, false))
	var down: bool = bool(held.get(KEY_DOWN, false))
	var left: bool = bool(held.get(KEY_LEFT, false))
	var right: bool = bool(held.get(KEY_RIGHT, false))
	var dash: int = absi(speed)
	var out: Dictionary = args.duplicate()
	# Each of the four bursts starts with its own velocity, without old-axis drift.
	run.script_movement.reset()
	var wanted: int = int(player_action.facing) if left == right else (1 if right else -1)
	sword_dash_face(run, wanted)
	if left or right:
		out["x"] = dash
		out["z"] = 0
		# dirValue is relative to facing, so using wanted here would flip twice.
		out["dirValue"] = 1
	elif up != down:
		out["x"] = 0
		out["z"] = -dash if up else dash
		out.erase("dirValue")
	else:
		out["x"] = dash
		out["z"] = 0
		out["dirValue"] = 1
	return out

static func sword_dash_frame(run, packet: Dictionary) -> void:
	if run == null or int(Game.role().get("career", 0)) != 110 or int(run.current_skill) == 0 or not run.action_player.active or int(run.action_player.action_id) != ACTION:
		return
	if not packet.get("scripts", []).any(func(script):return str(script.cmd) == "move" and int(script.args.get("x", 0)) != 0):
		return
	var held: Dictionary = run.action_player.held
	var left: bool = bool(held.get(KEY_LEFT, false))
	var right: bool = bool(held.get(KEY_RIGHT, false))
	# Resolve the direction before damage and keep the rendered mirror in sync.
	var wanted: int = int(run.action_player.facing) if left == right else (1 if right else -1)
	sword_dash_face(run, wanted)

static func sword_dash_face(run, wanted: int) -> void:
	run.action_player.facing = wanted
	var visual = run.player.get_node("Visual")
	# facing_left alone does not update AvatarView.scale.x. Reapply the same
	# motion so the body and weapon turn without restarting either timeline.
	visual.set_motion(int(visual.motion), wanted < 0)

# Appended to the existing skill steering helper; all changes are scoped by action.
const LANDING_META: String = "flash_landing_control"
const LIGHTNING_META: String = "flash_lightning_followup"
const LANDING_RADIUS: float = 140.0 # Two 70 px body collision boxes.

static func apply_flash(combat: Dictionary) -> int:
	var changed: int = 0
	# The original slow status also drives monster hitstun. Give this skill its
	# own two-second copy so other skills using 11301 retain their timing.
	var status_data: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/career_status.json"))
	for id in combat.catalog:
		var spec: Dictionary = combat.catalog[id]
		var action: int = int(spec.get("action", 0))
		if action == 300 and int(spec.get("career", 0)) == 300:
			var fields: Array = combat.fields[id].duplicate(true)
			var initial: PackedStringArray = str(fields[0].functions[3]).split(",", false)
			if not initial.has("9900212"):
				initial.append("9900212")
			fields[0].functions[3] = ",".join(initial)
			combat.fields[id] = fields
			changed += 1
		elif action == 309 and int(spec.get("career", 0)) == 310:
			var fields: Array = combat.fields[id].duplicate(true)
			for field in fields:
				var functions: PackedStringArray = str(field.functions[0]).split(",", false)
				for index in range(functions.size()):
					if int(functions[index]) >= 60301 and int(functions[index]) <= 60330:
						var level: int = int(spec.id) % 100
						var new_function: String = str(9902300 + level)
						var new_status: String = str(9901300 + level)
						var function: Dictionary = combat.functions[functions[index]].duplicate(true)
						function.attributes.id = new_function
						for effect in function.effects:
							if int(effect.get("data_type", 0)) == 4:
								var status: Dictionary = status_data.statuses[str(effect.data_1)].duplicate(true)
								status.attributes.id = new_status
								status.attributes.duration = "20" # 20 tenths = 60 combat ticks.
								combat.statuses[new_status] = status
								effect.data_1 = new_status
						combat.functions[new_function] = function
						functions[index] = new_function
				field.functions[0] = ",".join(functions)
				# Hit-freeze runs before hitstun; remove the extra five ticks so
				# the complete grounded immobilization is exactly 60 ticks.
				field.freeze = 0
			combat.fields[id] = fields
			changed += 1
	var motions: Dictionary = combat.career_motions["300"]
	for action in [307, 308]:
		var motion: Dictionary = motions[str(action)].duplicate(true)
		var followup: int = 316000 if action == 307 else 315000
		var registration_frame: int = 8 if action == 307 else 3
		for frame in motion.frames:
			var scripts: Array = []
			for original in frame.scripts:
				var script: Dictionary = original.duplicate(true)
				if str(script.cmd) == "acceptVKey" and int(script.args.get("argStr", 0)) == followup:
					continue
				if str(script.cmd) == "cancelAction" and int(frame.index) >= registration_frame:
					script.args.clear = "0"
				scripts.append(script)
			if int(frame.index) == registration_frame:
				scripts.append({"cmd": "acceptVKey", "args": {"cmd": "nextAction", "argStr": str(followup), "vkeys": "50001|13", "clear": "1", "checkUp": "0", "limitFrames": "30", "limitMapY": "0", "limitStep": "0", "checkNow": "0", "allowHeldForward": "1"}})
			frame.scripts = scripts
		var final_frame: Dictionary = motion.frames.back()
		final_frame.ticks = 15
		final_frame.fire_time = 1
		motion.duration = int(final_frame.tick) + 15
		motions[str(action)] = motion
	return changed

static func flash_action(run) -> int:
	if run == null or int(Game.base_career()) != 300 or int(run.current_skill) == 0 or not run.action_player.active:
		return 0
	return int(run.action_player.action_id)

static func clear_flash(run) -> void:
	preload("res://scripts/skill_pull.gd").release_lightning(run)
	for key in [LANDING_META, LIGHTNING_META]:
		if run.has_meta(key):
			run.remove_meta(key)

static func begin_flash(run, index: int) -> void:
	if index != 0:
		return
	clear_flash(run)
	var action: int = flash_action(run)
	if action == 301:
		run.set_meta(LANDING_META, Vector2.ZERO)
	elif action == 316 and int(Game.role().get("career", 0)) == 310:
		# Measure the original primary action's unobstructed scripted travel
		# through the native timeline, including its friction and state jumps.
		var total: float = lightning_distance(run)
		var ticks: int = 0
		for frame in run.action_player.motions["316"].frames:
			if int(frame.index) >= 1 and int(frame.index) <= 10:
				ticks += run.action_player.timeline.frame_duration(frame)
		run.set_meta(LIGHTNING_META, {"total": total * 0.6, "moved": 0.0, "step": total * 0.6 / maxi(1, ticks), "facing": run.action_player.facing})

static func lightning_distance(run) -> float:
	var action = preload("res://scripts/flash/action_player.gd").new()
	var movement = preload("res://scripts/flash/script_movement.gd").new()
	action.configure(Game.flash_actions, run.action_player.motions)
	action.facing = 1
	action.script_requested.connect(func(command: String, args: Dictionary):
		if command == "move":
			movement.execute(args, 1, {}, 0))
	if not action.begin(310, 307, run.action_player.attack_speed):
		return 0.0
	var point: Vector2 = Vector2.ZERO
	for tick in range(300):
		if not action.active:
			break
		point = movement.advance(point)
		action.advance()
	return absf(point.x)

static func flash_frame(run, packet: Dictionary) -> void:
	sword_dash_frame(run, packet)
	if flash_action(run) != 316 or not run.has_meta(LIGHTNING_META):
		return
	var index: int = int(packet.get("index", -1))
	if index < 1 or index > 10:
		return
	var progress: Dictionary = run.get_meta(LIGHTNING_META)
	var step: float = minf(float(progress.step), maxf(0.0, float(progress.total) - float(progress.moved)))
	# Consume attempted travel at a wall as well; no teleport or stored push.
	run.player.move_and_collide(Vector2(step * int(progress.facing), 0.0))
	progress.moved = float(progress.moved) + step
	preload("res://scripts/skill_pull.gd").advance_lightning(run)

static func walk_speed(run) -> float:
	var speed: float = float(run.player.speed)
	var character: Dictionary = Game.role()
	if not character.is_empty():
		var baseline: float = float(Game.gameplay_data.player_baselines[str(clampi(int(character.level), 1, 99))].get("2017", 120))
		speed *= float(Game.character_attributes().get("2017", baseline)) / maxf(1.0, baseline)
	return speed * float(run.source_status.model({"walkV": 1.0}).walkV)

static func flash_control(run) -> bool:
	if magnetic_control(run):
		return true
	var action: int = flash_action(run)
	if action not in [301, 304]:
		return false
	var held: Dictionary = run.action_player.held
	var x: int = int(bool(held.get(3, false))) - int(bool(held.get(2, false)))
	var z: int = int(bool(held.get(1, false))) - int(bool(held.get(0, false)))
	var direction: Vector2 = Vector2(x, z).limit_length(1.0)
	if action == 304:
		if run.control_args.is_empty():
			return true
		# One normal walk step per combat tick, regardless of a held run key.
		run.player.move_and_collide(direction * walk_speed(run) / 30.0)
	elif run.skill_air and run.player.jump_height > 0 and run.action_player.timeline.frame_index < 4:
		var offset: Vector2 = run.get_meta(LANDING_META, Vector2.ZERO)
		var wanted: Vector2 = (offset + direction * walk_speed(run) / 30.0 * 2.0).limit_length(LANDING_RADIUS)
		var before: Vector2 = run.player.position
		run.player.move_and_collide(wanted - offset)
		run.set_meta(LANDING_META, offset + run.player.position - before)
	else:
		return true
	if x != 0:
		run.action_player.facing = x
		run.player.get_node("Visual").facing_left = x < 0
	return true


const TONGLING_PENDING: String = "tongling_hidden_pending"
const TONGLING_GRACE: String = "tongling_hidden_grace"
const TONGLING_MAGNETIC: String = "tongling_magnetic_slash"
const TONGLING_GRACE_MS: int = 800

static func tongling_action(run) -> int:
	if run == null or int(Game.role().get("career", 0)) != 130 or int(run.current_skill) == 0 or not run.action_player.active:
		return 0
	return int(run.action_player.action_id)

static func tongling_hidden_id(group: int) -> int:
	return int(Game.innate_followup_skill_id(group * 100 + 1))

static func tongling_ready(run, id: int) -> bool:
	if id <= 0 or not Game.has_skill(id) or int(run.cooldowns.get(Game.skill_cooldown_key(id), 0)) > 0:
		return false
	var spec: Dictionary = Game.slice_data.skills.get(str(id), {})
	return not spec.is_empty() and int(run.mp) >= int(spec.hits[0].get("mana", 0))

static func tongling_window(action: int, state: int) -> int:
	# First arc slash continues into its ordinary second attack.
	return 8 if action == 109 and state > 0 else 4

# Positive: continue the normal skill pipeline with this id. Negative: accepted
# and buffered/branched. Zero: consumed but the hidden skill is unavailable.
static func tongling_request(run, requested: int) -> int:
	if int(Game.role().get("career", 0)) != 130:
		return requested
	var action: int = tongling_action(run)
	var group: int = requested / 100
	if action in [102, 109] and group == action:
		if action == 109 and int(run.action_player.state_index) == 0:
			if int(run.action_player.timeline.frame_index) >= 4:
				run.action_player.set_state(1)
			else:
				run.set_meta(TONGLING_PENDING, {"base": 109, "state": 1})
			return -1
		var target: int = 139 if action == 109 else 140
		if not tongling_ready(run, tongling_hidden_id(target)):
			return 0
		if int(run.action_player.timeline.frame_index) >= tongling_window(action, int(run.action_player.state_index)):
			run.action_player.stop(target * 1000)
		else:
			run.set_meta(TONGLING_PENDING, {"base": action, "target": target})
		return -1
	if run.current_skill != 0:
		return requested
	if group in [102, 109] and run.has_meta(TONGLING_GRACE):
		var grace: Dictionary = run.get_meta(TONGLING_GRACE)
		if int(grace.base) == group and Time.get_ticks_msec() <= int(grace.until):
			var target: int = tongling_hidden_id(int(grace.target))
			if tongling_ready(run, target):
				run.remove_meta(TONGLING_GRACE)
				return target
	var magnetic_clock: Dictionary = run.source_status.active.get("15001", {})
	if group == 138 and bool(magnetic_clock.get("tongling_hidden_used", false)):
		return 0
	if requested in [4, int(Game.normal_skill_id())] and run.player.running and not run.player.jumping and not magnetic_clock.is_empty() and not bool(magnetic_clock.get("tongling_hidden_used", false)):
		var target: int = tongling_hidden_id(138)
		if not tongling_ready(run, target):
			return requested
		var direction: Vector2 = Input.get_vector("move_left", "move_right", "move_up", "move_down")
		if direction.is_zero_approx():
			direction = run.player.velocity.normalized()
		if direction.is_zero_approx():
			direction = Vector2(-1 if run.player.get_node("Visual").facing_left else 1, 0)
		if not is_zero_approx(direction.x):
			run.player.get_node("Visual").facing_left = direction.x < 0
		run.set_meta(TONGLING_MAGNETIC, {"direction": direction.normalized(), "movement": preload("res://scripts/flash/script_movement.gd").new()})
		return target
	return requested

static func tongling_begin(run, index: int) -> void:
	if tongling_action(run) == 109 and index == 1 and run.has_meta(TONGLING_PENDING):
		var pending: Dictionary = run.get_meta(TONGLING_PENDING)
		if pending.has("state"):run.remove_meta(TONGLING_PENDING)
	if index != 0:
		return
	if tongling_action(run) == 138 and run.source_status.active.has("15001"):
		run.source_status.active["15001"]["tongling_hidden_used"] = true
	for key in [TONGLING_PENDING, TONGLING_GRACE]:
		if run.has_meta(key):run.remove_meta(key)
	if tongling_action(run) != 138 and run.has_meta(TONGLING_MAGNETIC):
		run.remove_meta(TONGLING_MAGNETIC)

static func tongling_frame(run, packet: Dictionary) -> void:
	var action: int = tongling_action(run)
	if action not in [102, 109]:
		return
	# Only another call to this same base skill can request the hidden branch.
	# Keep the original optional second ordinary arc slash, but remove the old
	# direction+command hidden registrations for this career alone.
	var target: int = 139 if action == 109 else 140
	packet.scripts = packet.get("scripts", []).filter(func(script):return not (str(script.cmd) == "acceptVKey" and int(script.args.get("argStr", 0)) == target * 1000))
	var index: int = int(packet.get("index", -1))
	if run.has_meta(TONGLING_PENDING):
		var pending: Dictionary = run.get_meta(TONGLING_PENDING)
		if int(pending.base) == action and index >= tongling_window(action, int(run.action_player.state_index)):
			run.remove_meta(TONGLING_PENDING)
			if pending.has("state"):
				run.action_player.set_state(int(pending.state))
			else:
				run.action_player.stop(int(pending.target) * 1000)
			return
	if str(packet.get("event", "")) == "onFrameEnd" and (action != 109 or int(run.action_player.state_index) > 0):
		run.set_meta(TONGLING_GRACE, {"base": action, "target": target, "until": Time.get_ticks_msec() + TONGLING_GRACE_MS})

static func tongling_finish(run, next_key: int) -> void:
	if run.has_meta(TONGLING_PENDING):run.remove_meta(TONGLING_PENDING)
	if run.has_meta(TONGLING_MAGNETIC):run.remove_meta(TONGLING_MAGNETIC)
	# A queued follow-up or another skill does not retain an old grace window.
	if next_key != -1 and run.has_meta(TONGLING_GRACE):run.remove_meta(TONGLING_GRACE)

static func magnetic_adjust(run, args: Dictionary) -> Dictionary:
	if tongling_action(run) != 138 or not run.has_meta(TONGLING_MAGNETIC):
		return args
	var slash: Dictionary = run.get_meta(TONGLING_MAGNETIC)
	slash.movement.execute(args, 1, {}, 0)
	var out: Dictionary = args.duplicate()
	out["stop"] = 1
	out["stopDir"] = -1
	return out

static func magnetic_control(run) -> bool:
	if tongling_action(run) != 138 or not run.has_meta(TONGLING_MAGNETIC):
		return false
	var slash: Dictionary = run.get_meta(TONGLING_MAGNETIC)
	var distance: Vector2 = slash.movement.advance(Vector2.ZERO)
	run.player.move_and_collide(Vector2(slash.direction) * absf(distance.x))
	return true

static func magnetic_relative(run, skill_id: int, relative: Vector2, facing: int) -> Vector2:
	if skill_id / 100 != 138 or tongling_action(run) != 138 or not run.has_meta(TONGLING_MAGNETIC):
		return relative
	var slash: Dictionary = run.get_meta(TONGLING_MAGNETIC)
	var direction: Vector2 = slash.direction
	return Vector2(relative.dot(direction) * facing, relative.cross(direction))

const PHX_AIR: String = "phoenix_air_cast"
const PHX_BUFFER: String = "phoenix_followup_buffer"
const PHX_GRACE: String = "phoenix_followup_grace"
const PHX_TOKEN: String = "phoenix_followup_token"
const PHX_LOCK: String = "phoenix_chain_lock"

static func phoenix_action(run) -> int:
	return int(Game.slice_data.skills.get(str(int(run.current_skill)),{}).get("action",0))

static func phoenix_armor(run) -> bool:
	if not run.action_player.active or int(run.current_skill)==0:return false
	var action: int=phoenix_action(run)
	var career: int=int(Game.role().get("career",0))
	if int(Game.base_career())==100 and action==101:return true
	if int(Game.base_career())!=400:return false
	if action in [405,410]:return true
	if career==410:return action in [414,417,424,422,425]
	return career==420 and action in [431,432,434,437,438,439]

static func apply_phoenix(combat: Dictionary) -> int:
	var motion: Dictionary=combat.career_motions["400"]["410"]
	for frame in motion.frames:
		for script in frame.scripts:
			if str(script.cmd)=="move" and int(script.args.get("x",0))!=0:
				script.args.x=str(int(round(float(script.args.x)*1.4)))
				script.args.fRate=str(float(script.args.get("fRate",1))*1.4)
			if str(script.cmd)=="createEffect":
				script.args.bind="1";script.args.follow_visual="1"
	# Followups can only start with a one-use token from their parent action.
	# The parent's timer owns the cast; no second timer can block the next cast.
	for id in combat.catalog:
		if int(combat.catalog[id].action) in [423,436]:combat.catalog[id].cooldown=0
	for frame in combat.career_motions["400"]["435"].frames:
		for script in frame.scripts:
			if str(script.cmd)=="acceptVKey" and int(script.args.get("argStr",0))==436000:
				script.args.allowHeldForward="1";script.args.limitFrames="18"
	apply_moon_windows(combat)
	apply_phoenix_effect_binding(combat)
	apply_combat_traits(combat)
	apply_sword_feedback(combat)
	return 1

static func phoenix_air_skill(skill: int) -> bool:
	return int(Game.base_career())==400 and int(Game.slice_data.skills.get(str(skill),{}).get("action",0)) in [410,419,421]

static func phoenix_followup_ready(run, action: int) -> bool:
	var frame: int=int(run.action_player.timeline.frame_index)
	return (action==422 and int(run.combo)==1 and frame>=27 and frame<=30) or (action==435 and frame>=12 and frame<=18)

static func phoenix_request(run, requested: int) -> int:
	if int(Game.base_career())!=400 or run.has_meta("phoenix_starting"):return -1
	var spec: Dictionary=Game.slice_data.skills.get(str(requested),{})
	var action: int=int(spec.get("action",0))
	if action in [423,436]:
		var token: Dictionary=run.get_meta(PHX_TOKEN,{})
		if int(token.get("action",0))!=action or int(token.get("until",-1))<int(run.ticks):return 0
		run.remove_meta(PHX_TOKEN)
		return -1
	if action==422 and phoenix_action(run)==422 and run.action_player.active and int(run.combo)==0:
		return 1 if moon_repeat(run) else 0
	if action in [422,435] and phoenix_action(run)==action and run.action_player.active:
		run.set_meta(PHX_BUFFER,{"action":action,"until":int(run.ticks)+20})
		if phoenix_followup_ready(run,action):run.action_player.stop(423000 if action==422 else 436000)
		return 1
	if action in [422,435] and int(run.current_skill)==0:
		var grace: Dictionary=run.get_meta(PHX_GRACE,{})
		if int(grace.get("action",0))==action and int(grace.get("until",-1))>=int(run.ticks):
			run.remove_meta(PHX_GRACE)
			var child: int=423 if action==422 else 436
			var selected: int=Game.innate_followup_skill_id(child*100+1)
			if selected==0:return 0
			run.set_meta(PHX_TOKEN,{"action":child,"until":int(run.ticks)+3})
			return 1 if run.request_skill(selected) else 0
	if not phoenix_air_skill(requested) or run.player.jump_height<=0:return -1
	if int(run.current_skill)!=0 and phoenix_action(run) not in [417,420]:return -1
	var id: int=Game.learned_skill_id(action)
	if id==0 or not Game.has_skill(id):return 0
	spec=Game.slice_data.skills[str(id)]
	if int(run.cooldowns.get(Game.skill_cooldown_key(id),0))>0:
		preload("res://scripts/recovery_rules.gd").reject_cooldown(run,id)
		return 0
	if run.mp<int(spec.hits[0].mana) or run.angry<int(spec.hits[0].get("angry",0)):return 0
	var height: int=int(run.player.jump_height)
	if int(run.current_skill)!=0:run.action_player.stop(-1)
	run.player.jumping=false;run.player.jump_height=height
	run.set_meta("phoenix_starting",true)
	var accepted: bool=run.request_skill(id)
	run.remove_meta("phoenix_starting")
	if not accepted:return 0
	run.set_meta(PHX_AIR,{"action":action,"height":height})
	run.skill_land.clear();run.skill_air=true;run.air_normal_attack=true;run.skill_air_velocity=0
	run.player.get_node("Visual").position.y=-height
	run.action_player.map_height=height
	if action==410:
		run.action_player.timeline.goto_frame(5)
		run.player.get_node("Visual").begin_action_motion(410,5,run.action_player.attack_speed)
	elif action==419:run.action_player.set_state(2)
	else:run.action_player.set_state(16)
	return 1

static func phoenix_input(run, key: int, pressed: bool) -> bool:
	if not pressed or int(Game.base_career())!=400:return false
	if key>=1000:
		for action in [410,419,421]:
			if key/1000==action and run.player.jump_height>0:
				return phoenix_request(run,Game.learned_skill_id(action))==1
	var action: int=phoenix_action(run)
	if key>=1000 and key/1000!=action:return false
	if action==422 and int(run.combo)==0 and key%1000==13:return moon_repeat(run)
	var forward: int=3 if int(run.action_player.facing)>0 else 2
	var direction_held: bool=bool(run.action_player.held.get(1,false)) or (action==435 and bool(run.action_player.held.get(forward,false)))
	if action in [422,435] and key%1000==13 and direction_held:
		return phoenix_request(run,int(run.current_skill))==1
	return false

static func phoenix_move(run, args: Dictionary) -> Dictionary:
	if not run.has_meta(PHX_AIR):return args
	var action: int=phoenix_action(run)
	if action not in [419,421]:return args
	var frame: int=int(run.action_player.timeline.frame_index)
	if action==419 and frame>=17:return args
	var out: Dictionary=args.duplicate()
	out.y="0";out.useCurrentVY="0";out.gRate="0"
	if int(out.get("stop",0))==1:out.stopDir="1"
	return out

static func phoenix_aux(run) -> void:
	moon_repeat_tick(run)
	if run.has_meta(PHX_BUFFER):
		var buffer: Dictionary=run.get_meta(PHX_BUFFER)
		if int(buffer.until)<int(run.ticks) or phoenix_action(run)!=int(buffer.action):run.remove_meta(PHX_BUFFER)
		elif phoenix_followup_ready(run,int(buffer.action)):
			run.remove_meta(PHX_BUFFER)
			run.action_player.stop(423000 if int(buffer.action)==422 else 436000)
	if not run.has_meta(PHX_AIR):return
	var action: int=phoenix_action(run)
	if not run.action_player.active or action!=int(run.get_meta(PHX_AIR).action):
		run.remove_meta(PHX_AIR);return
	var frame: int=int(run.action_player.timeline.frame_index)
	if action==421 and frame>=103:
		run.action_player.stop(-1)
		return
	if action==421 or (action==419 and frame<17):
		run.skill_air=true;run.skill_air_velocity=0;run.gravity_rate=0
	elif action==419 and frame>=17:
		run.gravity_rate=1
		if run.skill_air_velocity>=0:run.skill_air_velocity=-1

static func phoenix_finish(run, next_vkey: int) -> void:
	var action: int=phoenix_action(run)
	if int(Game.base_career())==400 and action in [422,435]:
		var child: int=423 if action==422 else 436
		if next_vkey==child*1000 and (action!=422 or phoenix_followup_ready(run,422)):
			run.set_meta(PHX_TOKEN,{"action":child,"until":int(run.ticks)+3})
			if run.has_meta(PHX_GRACE):run.remove_meta(PHX_GRACE)
		elif next_vkey==-1 and ((action==422 and phoenix_followup_ready(run,422)) or (action==435 and int(run.action_player.timeline.frame_index)>=13)):
			run.set_meta(PHX_GRACE,{"action":action,"until":int(run.ticks)+18})
	for key in [PHX_AIR,PHX_BUFFER,PHX_MOON_REPEAT]:
		if run.has_meta(key):run.remove_meta(key)

static func phoenix_interact_state(host, value: int) -> void:
	if int(host.spec.type)==40001 and int(host.skill_id)/100==435 and value==3:host.skill_index=1

static func phoenix_begin(run, index: int) -> void:
	if index!=0 or phoenix_action(run)!=436:return
	var storms: Array=run.interact_attacks.filter(func(item):return is_instance_valid(item) and not item.ended and int(item.spec.type)==40001 and int(item.skill_id)/100==435)
	if storms.is_empty():
		for id in [42003,42004]:
			var item=run.spawn_interact({"id":id,"x":30,"z":0},Game.learned_skill_id(435),1,run.player.position,0,run.action_player.facing)
			if is_instance_valid(item):storms.append(item)
	for item in storms:
		item.special.activated=true
		item.change_state(3)

static func phoenix_chain_ready(host) -> bool:
	if int(host.spec.type)!=20012 or int(host.skill_id)/100!=437 or host.hostile:return false
	host.attack_model=host.run.player_attack_model().duplicate(true)
	host.set_meta("phoenix_chain_targets",[])
	host.set_meta("phoenix_chain_seed",host.position)
	host.state=1;host.hide()
	return true

static func phoenix_chain_candidates(host, center: Vector2, height: float) -> Array:
	var result: Array=[]
	for enemy in host.run.monsters:
		if not is_instance_valid(enemy) or enemy.dead or enemy.caught or enemy.skill_status.has_class(11):continue
		var delta: Vector2=enemy.position-center
		if absf(delta.x)<=host.argument(host.spec.args,1,200) and absf(delta.y)<=host.argument(host.spec.args,2,70) and absf(enemy.air_height-height)<=host.argument(host.spec.args,3,150):result.append(enemy)
	result.sort_custom(func(a,b):return a.position.distance_squared_to(center)<b.position.distance_squared_to(center))
	return result

static func phoenix_chain_tick(host) -> bool:
	if int(host.spec.type)!=20012 or int(host.skill_id)/100!=437 or host.hostile:return false
	if host.ended:return true
	if not host.run.active or host.run.status not in ["battle","complete"]:
		host.finish();return true
	host.age+=1
	var duration: int=int(host.argument(host.spec.args,0,45))
	if host.age>duration:
		host.finish();return true
	var targets: Array=host.get_meta("phoenix_chain_targets",[])
	if targets.is_empty():
		var choices: Array=phoenix_chain_candidates(host,host.get_meta("phoenix_chain_seed"),host.height)
		if not choices.is_empty():targets.append(weakref(choices[0]))
	# Each pulse propagates from the already connected targets, never globally.
	var period: int=maxi(1,int(duration/maxi(1,int(Game.slice_data.skills[str(host.skill_id)].hits[0].multiple))))
	if host.age<duration and host.age%period==0:
		var next: Array=targets.duplicate()
		for reference in targets:
			var source=reference.get_ref()
			if not is_instance_valid(source) or source.dead:continue
			for enemy in phoenix_chain_candidates(host,source.position,source.air_height):
				if not next.any(func(item):return item.get_ref()==enemy):next.append(weakref(enemy))
		targets=next
		for reference in targets:
			var enemy=reference.get_ref()
			if is_instance_valid(enemy) and not enemy.dead and not enemy.caught and not enemy.skill_status.has_class(11):phoenix_chain_damage(host,enemy)
	for reference in targets:
		var enemy=reference.get_ref()
		if not is_instance_valid(enemy) or enemy.dead or enemy.caught or enemy.skill_status.has_class(11):continue
		if not enemy.has_meta(PHX_LOCK):enemy.set_meta(PHX_LOCK,{"owner":weakref(host),"motion":enemy.motion,"frame":enemy.animation_frame_ref})
		enemy.cancel_attack();enemy.set_motion("11")
	host.set_meta("phoenix_chain_targets",targets)
	return true

static func phoenix_chain_damage(host, enemy) -> void:
	var hit: Dictionary=Game.slice_data.skills[str(host.skill_id)].hits[0]
	var result: Dictionary=preload("res://scripts/flash/damage_calculator.gd").calculate(host.attack_model,enemy.effective_attributes(),hit,host.facing,-1 if enemy.left else 1,enemy.attack_tick>=0,host.run.combat_random.next_float)
	if bool(result.miss):return
	enemy.set_meta("damage_skill_id",int(host.skill_id));enemy.set_meta("damage_critical",bool(result.critical))
	var reaction: Dictionary=Game.career_combat.fields[str(host.skill_id)][0].duplicate(true)
	reaction.power_x=0;reaction.power_y=0;reaction.air_power_x=0;reaction.air_power_y=0
	enemy.damage(int(result.damage),Vector2.ZERO,false,reaction)
	host.run.record_hit(int(result.damage))
	host.run.apply_skill_functions(host.skill_id,0,0,enemy)
	preload("res://scripts/slice_effect.gd").spawn_at(host.run.player,43701,enemy.position,enemy.air_height+50,host.facing,"hit")
	host.run.record("hit",{"skill":int(host.skill_id),"monster":enemy.monster_id,"damage":int(result.damage),"combo":0,"chain":true})

static func phoenix_chain_monster_tick(enemy) -> bool:
	if not enemy.has_meta(PHX_LOCK):return false
	var state: Dictionary=enemy.get_meta(PHX_LOCK)
	var host=state.owner.get_ref()
	if not is_instance_valid(host) or host.ended or enemy.dead or enemy.caught or not host.run.active or enemy.skill_status.has_class(11):
		enemy.remove_meta(PHX_LOCK)
		if not enemy.dead and not enemy.caught and enemy.motion=="11":
			enemy.set_motion(str(state.motion) if enemy.airborne or enemy.lie_ticks>0 or enemy.getting_up else ("11" if enemy.stun>0 else "3"))
			enemy.animation_frame_ref=int(state.frame) if enemy.airborne or enemy.lie_ticks>0 or enemy.getting_up else -1
		return false
	enemy.advance_source_statuses()
	if enemy.dead:return true
	preload("res://scripts/armor_glow.gd").refresh_monster(enemy)
	enemy.cancel_attack();enemy.set_motion("11");enemy.animation_tick+=1;enemy.render_frame()
	return true

const PHX_MOON_REPEAT: String = "phoenix_moon_repeat"

static func apply_moon_windows(combat: Dictionary) -> void:
	# The opening dash's window continues the authored normal chain. Only the
	# separate finishing state may offer the hidden move.
	var frame: Dictionary=combat.career_motions["400"]["422"].frames[5]
	frame.scripts=frame.scripts.filter(func(script):return not (str(script.cmd)=="acceptVKey" and int(script.args.get("argStr",0))==423000))

static func moon_repeat(run) -> bool:
	if phoenix_action(run)!=422 or int(run.combo)!=0:return false
	run.set_meta(PHX_MOON_REPEAT,{"until":int(run.ticks)+20})
	moon_repeat_tick(run)
	return true

static func moon_repeat_tick(run) -> void:
	if not run.has_meta(PHX_MOON_REPEAT):return
	var buffer: Dictionary=run.get_meta(PHX_MOON_REPEAT)
	if phoenix_action(run)!=422 or int(run.combo)!=0 or int(buffer.until)<int(run.ticks):
		run.remove_meta(PHX_MOON_REPEAT);return
	var frame: int=int(run.action_player.timeline.frame_index)
	if frame>=5 and frame<=8:
		run.remove_meta(PHX_MOON_REPEAT)
		var back: int=2 if int(run.action_player.facing)>0 else 3
		run.action_player.virgate("gotoAndPlay",9 if bool(run.action_player.held.get(back,false)) else 11)

static func apply_phoenix_effect_binding(combat: Dictionary) -> void:
	# The rise/slash ribbons belong to the displayed body. Ground impact dust
	# and detached landing bursts retain their authored world coordinates.
	for action in [417,421]:
		var frames: Array=combat.career_motions["400"][str(action)].frames
		for index in frames.size():
			if action==421 and index<68:continue
			for script in frames[index].scripts:
				if str(script.cmd)!="createEffect":continue
				var id: int=int(script.args.get("id",0))
				if action==417 and id not in [41701,41702,41703,41704,41705,41706,41707,31904]:continue
				script.args.bind="1";script.args.phoenix_visual="1"

static func attach_phoenix_effect(effect,actor,args: Dictionary) -> bool:
	if int(args.get("phoenix_visual",0))!=1:return false
	var visual=actor.get_node_or_null("Visual")
	if visual==null:return false
	var art_scale: float=maxf(0.00001,absf(visual.scale.y))
	effect.base_offset/=art_scale
	effect.original_scale/=art_scale
	# Visual already mirrors the complete body for left-facing actions. Keep
	# effect coordinates in that local space, so facing is applied exactly once.
	effect.left=false
	effect.position=effect.base_offset
	effect.set_meta("phoenix_visual",true)
	visual.add_child(effect)
	if float(args.get("z",0))+float(args.get("deep",0))<0:visual.move_child(effect,0)
	return true

# Remove only the M9 burst counter branch. The original recoil loop, shot
# script, per-shot interval, ageing state and terminal explosion stay intact.
static func apply_combat_traits(combat: Dictionary) -> void:
	var turret: Dictionary=combat.interacts["60010"]
	for motion in ["0","1"]:
		for script in turret.motions[motion].frames[6].scripts:
			if str(script.cmd)=="variable" and str(script.args.get("argStr",""))=="7":
				script.cmd="gotoAndPlay";script.args={"argStr":"7"}
		for layer in turret.art.layers:
			if not layer.motions.has(motion):continue
			for script in layer.motions[motion][6].scripts:
				if str(script.cmd)=="variable" and str(script.args.get("argStr",""))=="7":
					script.cmd="gotoAndPlay";script.args={"argStr":"7"}


static func apply_sword_feedback(combat: Dictionary) -> void:
	# Match the two modest advances already used by Rift Slash, keeping the
	# original nuclear leap, descent, landing scripts and damage untouched.
	var motion: Dictionary=combat.career_motions["100"]["126"]
	for index in [4,6]:
		for script in motion.frames[index].scripts:
			if str(script.cmd)=="move" and int(script.args.get("stop",0))==0:
				script.args.x="2100";script.args.walkV="0"

# Only visual roots are relocated. Native field positions, damage areas, hit
# quotas, skill stages and beam lifetimes stay on their original battle clock.
static func cannon_visual_pair(parent_id: int, child_id: int) -> bool:
	if parent_id == 60060:return child_id == 60062
	if parent_id in [60125,60149,60150,60151,60152,60153]:return child_id in [60134,60165]
	return parent_id in [60145,60124,60144,60146,60160,60161] and child_id == 60148

static func cannon_art_pose(host) -> Transform2D:
	if host.parts.is_empty():return Transform2D.IDENTITY
	var clock=host.parts[0].clock
	if clock.frames.is_empty():return Transform2D.IDENTITY
	var frame: Dictionary=clock.frames[clampi(clock.frame_index,0,clock.frames.size()-1)]
	var offset: Vector2=Vector2((float(frame.translation[0])+float(frame.origin[0])*float(frame.scale[0]))*host.facing,float(frame.translation[1])+float(frame.origin[1])*float(frame.scale[1]))
	offset=offset.rotated(deg_to_rad(host.visual_rotation))
	return Transform2D(deg_to_rad(float(frame.rotation)*host.facing+host.visual_rotation),Vector2(float(frame.scale[0])*host.facing,float(frame.scale[1])),0,offset)

static func bind_cannon_visual(host, beam, values: Dictionary) -> void:
	if not cannon_visual_pair(int(host.spec.id),int(beam.spec.id)):return
	var offset: Vector2=Vector2(float(values.get("x",0))*host.facing,float(values.get("z",0))-float(values.get("y",0)))
	beam.set_meta("cannon_visual_source",weakref(host))
	beam.set_meta("cannon_visual_marker",cannon_art_pose(host).affine_inverse()*offset)
	beam.set_meta("cannon_visual_depth",float(values.get("z",0))+float(values.get("deep",0)))
	sync_cannon_visual(beam)

static func sync_cannon_visual(beam) -> void:
	if not beam.has_meta("cannon_visual_source") or not is_instance_valid(beam.art_root):return
	var host=beam.get_meta("cannon_visual_source").get_ref()
	if not is_instance_valid(host) or host.ended:
		beam.art_root.hide()
		return
	var marker: Vector2=cannon_art_pose(host)*Vector2(beam.get_meta("cannon_visual_marker"))
	var target: Vector2=host.global_position+marker+Vector2(0,-host.height)
	# Height was already subtracted inside each native beam Sprite2D and custom
	# LaserSegments draw, so compensate it once at their common visual root.
	var depth=beam.art_root.get_parent()
	depth.global_position.y=host.global_position.y+host.depth_offset+float(beam.get_meta("cannon_visual_depth"))+0.125
	beam.art_root.global_position=target+Vector2(0,beam.height)
	beam.art_root.show()

static func sync_cannon_visuals(run) -> void:
	# Grouped orbit controllers move their cannons after those cannon ticks.
	# Flush visual bindings after the whole native pass, including newborn rays
	# which are not yet part of that pass's duplicate attack list.
	for beam in run.interact_attacks:
		if is_instance_valid(beam) and not beam.ended and beam.has_meta("cannon_visual_source"):
			sync_cannon_visual(beam)

static func spawn_cannon_flash(host,values: Dictionary) -> bool:
	var parent_id: int=int(host.spec.id)
	var effect_id: int=int(values.get("id",0))
	var point_cannon: bool=parent_id in [60125,60149,60150,60151,60152,60153]
	var thunder_cannon: bool=parent_id in [60145,60124,60144,60146,60160,60161]
	if not ((point_cannon and effect_id==25702) or (thunder_cannon and effect_id in [25702,25703])):return false
	var effect=load("res://scripts/slice_effect.gd").spawn_bound_interact(host.run.player,host,values)
	if effect==null:return true
	var offset: Vector2=Vector2(float(values.get("x",0))*host.facing,float(values.get("z",0))-float(values.get("y",0)))
	var marker: Vector2=cannon_art_pose(host).affine_inverse()*offset
	var sprite: Sprite2D=host.parts[0].sprite
	# The muzzle flash belongs to the cannon's displayed sprite, not the world
	# position at which it first fired. This also carries the inherited facing,
	# per-frame art translation and later movement of the entire cannon group.
	effect.reparent(sprite,false)
	effect.left=false;effect.interact_source=null
	effect.position=marker;effect.base_offset=marker
	effect.original_scale/=Vector2(maxf(absf(sprite.scale.x),0.00001),maxf(absf(sprite.scale.y),0.00001))
	effect.angle-=float(sprite.rotation_degrees)*host.facing
	effect.set_meta("cannon_flash_visual",true)
	effect.set_meta("cannon_flash_source",weakref(host))
	effect.apply_direction_transform();effect.render_frame()
	return true

static func apply_comet_visual_binding(combat: Dictionary) -> int:
	var changed: int=0
	for frame in combat.career_motions["300"]["350"].frames:
		for script in frame.scripts:
			if str(script.cmd)!="createEffect" or int(script.args.get("id",0)) not in [35001,13501,34406,50014,33901]:continue
			script.args.bind="1";script.args.comet_visual="1";changed+=1
	return changed

static func attach_comet_visual(effect,actor,args: Dictionary) -> bool:
	if int(args.get("comet_visual",0))!=1:return false
	var visual=actor.get_node_or_null("Visual")
	if visual==null:return false
	var art_scale: float=maxf(0.00001,absf(visual.scale.y))
	effect.base_offset/=art_scale;effect.original_scale/=art_scale
	effect.left=false;effect.position=effect.base_offset
	effect.set_meta("comet_visual",true)
	visual.add_child(effect)
	if float(args.get("z",0))+float(args.get("deep",0))<0:visual.move_child(effect,0)
	return true
