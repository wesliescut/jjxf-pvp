extends RefCounted

# 怪物能力开关：不可抓取 / 不可击飞 / 永久霸体 / 可打断。
# 数据在 data/boss_traits.json，未列出的怪物一律按普通怪物处理。

const PATH: String = "res://data/boss_traits.json"

static var _table: Dictionary = {}
static var _loaded: bool = false


static func _load() -> Dictionary:
	if not _loaded:
		_loaded = true
		if FileAccess.file_exists(PATH):
			var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
			if parsed is Dictionary:
				_table = parsed.get("bosses", {})
	return _table


static func _entry(monster):
	if monster == null:
		return null
	return _load().get(str(int(monster.monster_id)))


static func has_trait(monster, flag: String) -> bool:
	var entry = _entry(monster)
	if entry == null:
		return false
	return bool(entry.get(flag, false))


static func no_grab(monster) -> bool:
	return has_trait(monster, "no_grab")


static func no_launch(monster) -> bool:
	return has_trait(monster, "no_launch")


static func super_armor(monster) -> bool:
	return has_trait(monster, "super_armor")


# 可打断：连出招/施法期间的"boss 攻击霸体"也去掉，受击一律进入硬直。
static func interruptible(monster) -> bool:
	return has_trait(monster, "interruptible")
