extends RefCounted

# 霸体黄色光晕：复用 assets/shaders/item_glow.gdshader 的外发光效果，
# 只改材质，不动 alpha，因此与半透明/冰冻染色等状态可以共存。

const SHADER: String = "res://assets/shaders/armor_glow.gdshader"
const GLOW_COLOR: Color = Color(1.0, 0.82, 0.2, 1.0)
# 光晕半径（像素级）与强度：越大越厚越亮。
const GLOW_RADIUS: float = 3.0
const GLOW_STRENGTH: float = 1.0
const BODY_BOOST: float = 0.35

static var _material: ShaderMaterial


static func _glow_material() -> ShaderMaterial:
	if _material == null:
		_material = ShaderMaterial.new()
		var shader = load(SHADER)
		if shader == null:
			return null
		_material.shader = shader
		_material.set_shader_parameter("glow_color", GLOW_COLOR)
		_material.set_shader_parameter("radius", GLOW_RADIUS)
		_material.set_shader_parameter("strength", GLOW_STRENGTH)
		_material.set_shader_parameter("body_boost", BODY_BOOST)
	return _material


static func _apply(sprite, active: bool) -> void:
	if sprite == null:
		return
	var material: ShaderMaterial = _glow_material()
	if material == null:
		return
	if active:
		if sprite.material != material:
			sprite.material = material
	elif sprite.material == material:
		sprite.material = null


static func refresh_parts(parts: Array, active: bool) -> void:
	for part in parts:
		_apply(part.get("sprite"), active)


static func refresh_monster(monster) -> void:
	if monster == null or not is_instance_valid(monster):
		return
	var active: bool = preload("res://scripts/boss_guard.gd").guard_active(monster)
	refresh_parts(monster.layers, active)

# Player armor indication is a separate, body-only contour. The original
# material path above continues to serve monster guard rendering.
const BODY_OUTLINE_SHADER_CODE: String = "shader_type canvas_item;\nrender_mode unshaded;\n\nuniform vec4 line_color : source_color = vec4(1.0, 0.82, 0.2, 1.0);\nuniform float line_width = 2.0;\nuniform vec4 source_uv_rect = vec4(0.0, 0.0, 1.0, 1.0);\nuniform vec2 sprite_flip = vec2(1.0);\nvarying vec4 vertex_tint;\n\nvoid vertex() {\n\tvertex_tint = COLOR;\n\tvec2 unit_uv = (UV - source_uv_rect.xy) / source_uv_rect.zw;\n\tVERTEX += (unit_uv * 2.0 - 1.0) * line_width * sprite_flip;\n}\n\nvoid fragment() {\n\tvec2 unit_uv = (UV - source_uv_rect.xy) / source_uv_rect.zw;\n\tvec2 source_uv = UV + (unit_uv * 2.0 - 1.0) * line_width * TEXTURE_PIXEL_SIZE;\n\tfloat center_alpha = 0.0;\n\tif (source_uv.x >= source_uv_rect.x && source_uv.y >= source_uv_rect.y &&\n\t\tsource_uv.x < source_uv_rect.x + source_uv_rect.z && source_uv.y < source_uv_rect.y + source_uv_rect.w) {\n\t\tcenter_alpha = texture(TEXTURE, source_uv).a;\n\t}\n\tfloat neighbor_alpha = 0.0;\n\tfor (int y = -2; y <= 2; y++) {\n\t\tfor (int x = -2; x <= 2; x++) {\n\t\t\tvec2 step_pixels = vec2(float(x), float(y));\n\t\t\tif (length(step_pixels) <= 2.25) {\n\t\t\t\tvec2 point = source_uv + step_pixels * line_width * 0.5 * TEXTURE_PIXEL_SIZE;\n\t\t\t\tif (point.x >= source_uv_rect.x && point.y >= source_uv_rect.y &&\n\t\t\t\t\tpoint.x < source_uv_rect.x + source_uv_rect.z && point.y < source_uv_rect.y + source_uv_rect.w) {\n\t\t\t\t\tneighbor_alpha = max(neighbor_alpha, texture(TEXTURE, point).a);\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t}\n\t// This separate sprite draws only outside the source body's alpha mask.\n\t// The real body sprite and its own material are never recolored.\n\tfloat edge = (1.0 - step(0.1, center_alpha)) * step(0.1, neighbor_alpha);\n\tCOLOR = vec4(line_color.rgb, line_color.a * edge) * vertex_tint;\n}\n"

class ArmorBodyOutline extends Sprite2D:
	var body: Sprite2D
	var armor_enabled: bool = false

	func _ready() -> void:
		show_behind_parent = true
		use_parent_material = false
		texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		texture_repeat = CanvasItem.TEXTURE_REPEAT_DISABLED
		process_priority = 100

	func set_armor(value: bool) -> void:
		armor_enabled = value
		sync_body()

	func _process(_delta: float) -> void:
		sync_body()

	func sync_body() -> void:
		if not is_instance_valid(body):
			queue_free()
			return
		visible = armor_enabled and body.visible and body.texture != null
		if not visible:return
		texture = body.texture
		centered = body.centered
		offset = body.offset
		flip_h = body.flip_h;flip_v = body.flip_v
		region_enabled = body.region_enabled
		region_rect = body.region_rect
		region_filter_clip_enabled = true
		self_modulate = Color(1,1,1,body.self_modulate.a)
		var source: Texture2D = texture
		var crop: Rect2 = region_rect if region_enabled else Rect2(Vector2.ZERO,source.get_size())
		while source is AtlasTexture:
			var atlas: AtlasTexture = source as AtlasTexture
			crop.position += atlas.region.position
			source = atlas.atlas
		var size: Vector2 = source.get_size()
		var line_material: ShaderMaterial = material as ShaderMaterial
		line_material.set_shader_parameter("source_uv_rect",Vector4(crop.position.x/size.x,crop.position.y/size.y,crop.size.x/size.x,crop.size.y/size.y))
		line_material.set_shader_parameter("sprite_flip",Vector2(-1 if flip_h else 1,-1 if flip_v else 1))

static var _body_outline_shader: Shader

static func _body_outline(body: Sprite2D):
	var outline=body.get_node_or_null("ArmorBodyOutline")
	if outline != null:return outline
	if _body_outline_shader == null:
		_body_outline_shader=Shader.new()
		_body_outline_shader.code=BODY_OUTLINE_SHADER_CODE
	outline=ArmorBodyOutline.new()
	outline.name="ArmorBodyOutline";outline.body=body
	var line_material=ShaderMaterial.new()
	line_material.shader=_body_outline_shader
	line_material.set_shader_parameter("line_color",GLOW_COLOR)
	line_material.set_shader_parameter("line_width",2.0)
	outline.material=line_material
	body.add_child(outline)
	return outline

static func refresh_player(run) -> void:
	if run == null or not is_instance_valid(run.player):return
	var visual=run.player.get_node_or_null("Visual")
	if visual == null:return
	var active: bool=run.source_status.has_class(1) or preload("res://scripts/block_rules.gd").armor_active(run)
	# Remove only this helper's legacy yellow-fill material, including from
	# weapons. Existing equipment, hit, freeze and other shader materials remain.
	refresh_parts(visual.parts,false)
	for part in visual.parts:
		if not str(part.get("source_key","")).begins_with("player_") or int(part.get("layer_id",-1)) != 0:continue
		var body: Sprite2D=part.sprite
		var outline=body.get_node_or_null("ArmorBodyOutline")
		if outline == null and active:outline=_body_outline(body)
		if outline != null:outline.set_armor(active)
