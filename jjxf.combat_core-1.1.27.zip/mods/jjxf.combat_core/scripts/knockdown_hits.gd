extends RefCounted

# 倒地受击白名单：玩家处于倒地/起身阶段时默认免疫伤害，
# 只有 data/knockdown_damage.json 里列出的技能（按怪物技能 id）仍然能打到倒地玩家。
#
# 技能 id 就是 Game.career_combat.fields 的键，例如 13012。

const PATH: String = "res://data/knockdown_damage.json"

static var _data: Dictionary = {}
static var _loaded: bool = false


static func _table() -> Dictionary:
	if not _loaded:
		_loaded = true
		if FileAccess.file_exists(PATH):
			var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
			if parsed is Dictionary:
				_data = parsed
	return _data


static func downed(run) -> bool:
	if run == null:
		return false
	var reaction = preload("res://scripts/recovery_rules.gd").reaction_for(run)
	if reaction == null:
		return false
	return str(reaction.state) in ["lie", "get_up"]


static func allowed(skill_id: int) -> bool:
	if skill_id <= 0:
		return false
	for value in _table().get("skills", []):
		if int(value) == skill_id:
			return true
	return false


# 绕过倒地无敌结算一次伤害：临时清空 invincible，交给 hurt_player 走完整流程，再恢复保护。
static func strike(run, damage: int) -> void:
	if run == null or damage <= 0:
		return
	var rate: float = float(_table().get("damage_rate", 1.0))
	var amount: int = damage if rate >= 1.0 else maxi(1, int(float(damage) * rate))
	var saved: int = int(run.invincible)
	run.invincible = 0
	run.hurt_player(amount)
	run.invincible = maxi(saved, int(run.invincible))
