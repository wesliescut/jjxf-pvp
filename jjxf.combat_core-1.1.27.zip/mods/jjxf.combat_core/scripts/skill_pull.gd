extends RefCounted

const ACTION: int = 122
const STATE_PULL: int = 0
const RANGE_X: float = 460.0
const RANGE_Y: float = 90.0
const PULL_SPEED: float = 7.0
const STOP_DISTANCE: float = 120.0
const HOVER_RISE_STEP: float = 1.0
const BLAST_LIFT: int = 180
const PUSH_TICKS: int = 10
const PUSH_STEP: int = 24
const MARK: String = "fengmo_pulled"
const PUSH: String = "fengmo_push"

static func advance(run) -> void:
	if run == null:
		return
	process_pushes(run)
	var action = run.action_player
	if run.player == null or action == null:
		return
	if action.active and int(action.action_id) == ACTION and int(action.state_index) == STATE_PULL:
		pull(run, run.player, int(action.facing))
	else:
		# Damage polling cannot distinguish the slash from lingering first-stage hits.
		for monster in run.monsters:
			if is_instance_valid(monster) and monster.has_meta(MARK):
				monster.remove_meta(MARK)
			if is_instance_valid(monster):
				release_hover(monster)

static func pull(run, player, facing: int) -> void:
	for monster in run.monsters:
		if not usable(monster) or monster.has_meta(PUSH):
			continue
		var relative: Vector2 = monster.position - player.position
		if absf(relative.y) > RANGE_Y or absf(relative.x) > RANGE_X or relative.x * facing <= 0.0:
			continue
		var target: Vector2 = player.position + Vector2(facing * STOP_DISTANCE, 0)
		suspend_target(run, monster)
		monster.move_and_collide((target - monster.position).limit_length(PULL_SPEED))
		if monster.has_meta(HOVER_META):
			var state: Dictionary = monster.get_meta(HOVER_META)
			var remaining: float = monster.position.distance_to(target)
			var progress: float = clampf(1.0 - remaining / maxf(1.0, float(state.distance)), 0.0, 1.0)
			var desired_height: float = lerpf(float(state.initial_height), float(state.ceiling), progress)
			if remaining < 0.01 or float(state.distance) < 1.0:
				desired_height = float(state.ceiling)
			state.height = move_toward(float(state.height), desired_height, HOVER_RISE_STEP)
			monster.air_height = int(state.height)
		if not monster.has_meta(MARK):
			monster.set_meta(MARK, true)


static func on_hit(run, monster, skill_id: int, index: int, facing: int, damage: int) -> void:
	eagle_hit(run, monster, skill_id, facing, damage)
	lightning_hit(run, monster, skill_id, facing, damage)
	# The direct hit callback also works on targets with infinite HP and targets
	# that entered the slash area after the attraction phase.
	if index != 1 or damage <= 0 or not usable(monster):
		return
	var spec: Dictionary = Game.slice_data.skills.get(str(skill_id), {})
	if int(spec.get("action", 0)) != ACTION or int(spec.get("career", 0)) != 120:
		return
	if monster.has_meta(MARK):
		monster.remove_meta(MARK)
	# One push for one actual slash, even when its hit frame repeats.
	if monster.has_meta(PUSH):
		return
	blast(monster, -1 if facing < 0 else 1)

static func blast(monster, away: int) -> void:
	monster.set_meta(PUSH, {"dir": away, "ticks": PUSH_TICKS, "step": PUSH_STEP})
	# execute({x:0}) retains the previous velocity. Explicitly clear it so
	# first-stage movement cannot oppose the independent horizontal push.
	monster.script_movement.reset()
	var hit: Dictionary = {
		"power_x": 0, "power_y": BLAST_LIFT,
		"air_power_x": 0, "air_power_y": BLAST_LIFT,
		"random_dy": 0, "freeze": 2, "attack_type": 0,
	}
	if monster.has_method("apply_reaction"):
		monster.apply_reaction(hit, away)
	monster.script_movement.reset()

static func process_pushes(run) -> void:
	for monster in run.monsters:
		if not is_instance_valid(monster) or not monster.has_meta(PUSH):
			continue
		var push: Dictionary = monster.get_meta(PUSH)
		if bool(monster.dead) or int(push.get("ticks", 0)) <= 0:
			monster.remove_meta(PUSH)
			continue
		push["ticks"] = int(push.get("ticks", 0)) - 1
		monster.script_movement.reset()
		monster.move_and_collide(Vector2(int(push.get("dir", 1)) * int(push.get("step", PUSH_STEP)), 0))
		if int(push.ticks) <= 0:
			monster.remove_meta(PUSH)

static func usable(monster) -> bool:
	return is_instance_valid(monster) and not bool(monster.dead) and not bool(monster.boss)


const EAGLE_MARK: String = "branch_eagle_carrier"

static func eagle_hit(run, monster, skill_id: int, facing: int, damage: int) -> void:
	var spec: Dictionary = Game.slice_data.skills.get(str(skill_id), {})
	if damage <= 0 or int(spec.get("action", 0)) != 342 or int(spec.get("career", 0)) != 320 or not carry_allowed(monster):
		return
	var contact = run.get_meta(CONTACT_META, null)
	var carrier = contact.get_ref() if contact is WeakRef else null
	if not eagle_matches(carrier, skill_id, facing):
		return
	if monster.has_meta(EAGLE_MARK):
		var previous: Dictionary = monster.get_meta(EAGLE_MARK)
		if previous.carrier.get_ref() == carrier:
			# Repeated damage must not erase unconsumed projectile travel.
			apply_carried_pose(monster, float(previous.height))
			return
	prepare_carried(monster)
	var lift: float = maxf(30.0, float(monster.air_height))
	monster.set_meta(EAGLE_MARK, {"owner": weakref(run), "carrier": weakref(carrier), "x": float(carrier.position.x), "height": lift})
	apply_carried_pose(monster, lift)


static func advance_eagles(run) -> void:
	for monster in run.monsters:
		if not is_instance_valid(monster) or not monster.has_meta(EAGLE_MARK):
			continue
		var state: Dictionary = monster.get_meta(EAGLE_MARK)
		var carrier = state.carrier.get_ref()
		# Include the final travelled step even when this tick ended the entity.
		if is_instance_valid(carrier) and carry_allowed(monster):
			var distance: float = float(carrier.position.x) - float(state.x)
			state.x = float(carrier.position.x)
			monster.move_and_collide(Vector2(distance, 0))
		if not carry_state_valid(monster, state, true):
			monster.remove_meta(EAGLE_MARK)
			continue
		apply_carried_pose(monster, float(state.height))

const HOVER_META: String = "fengmo_hover"
const HOVER_HEIGHT: int = 40

static func hover_allowed(monster) -> bool:
	if not usable(monster) or monster.caught:
		return false
	if preload("res://scripts/boss_traits.gd").no_launch(monster) or preload("res://scripts/boss_guard.gd").guard_active(monster):
		return false
	return monster.get("armor") == null or int(monster.get("armor")) == 0

static func suspend_target(run, monster) -> void:
	if not hover_allowed(monster) or int(Game.role().get("career", 0)) != 120:
		return
	if not monster.has_meta(HOVER_META):
		prepare_carried(monster)
		var target: Vector2 = run.player.position + Vector2(int(run.action_player.facing) * STOP_DISTANCE, 0)
		var initial: float = float(monster.air_height)
		monster.set_meta(HOVER_META, {"owner": weakref(run), "height": initial, "initial_height": initial, "ceiling": maxf(HOVER_HEIGHT, initial), "distance": monster.position.distance_to(target)})
	# 禁锢要贴地：小怪如果正被击飞（air_height 可能 180+），把高度原样锁住会让它
	# 悬在玩家技能判定盒之上，表现就是「被禁锢了但打不到」。统一压到 HOVER_HEIGHT。
	monster.air_height = mini(int(monster.get_meta(HOVER_META).height), HOVER_HEIGHT)
	monster.air_velocity = 0
	monster.airborne = true
	monster.stun = 0
	monster.impact_freeze = 0
	monster.script_movement.reset()
	monster.set_motion("12")


static func release_hover(monster) -> void:
	if monster.has_meta(HOVER_META):monster.remove_meta(HOVER_META)
	# Leave the air height and velocity to the native fall/second-stage launch.

static func hover_tick(monster) -> bool:
	if not monster.has_meta(HOVER_META):
		return false
	var state: Dictionary = monster.get_meta(HOVER_META)
	var owner = state.owner.get_ref()
	if not is_instance_valid(owner) or not owner.active or not owner.action_player.active or int(owner.current_skill) == 0 or int(owner.action_player.action_id) != ACTION or int(owner.action_player.state_index) != STATE_PULL or not hover_allowed(monster):
		release_hover(monster)
		return false
	var relative: Vector2 = monster.position - owner.player.position
	if absf(relative.x) > RANGE_X or absf(relative.y) > RANGE_Y or relative.x * int(owner.action_player.facing) <= 0:
		release_hover(monster)
		return false
	monster.advance_source_statuses()
	if monster.dead:
		release_hover(monster)
		return false
	# 同 suspend_target：禁锢期间的高度必须压在 HOVER_HEIGHT 以内，
	# 否则被击飞的怪被禁锢后会浮在判定盒上方，技能全部打空。
	monster.air_height = mini(int(state.height), HOVER_HEIGHT)
	monster.air_velocity = 0
	monster.airborne = true
	monster.stun = 0
	monster.impact_freeze = 0
	monster.script_movement.reset()
	monster.set_motion("12")
	monster.render_frame()
	return true

const LIGHTNING_CARRY: String = "flash_lightning_carried"
const CONTACT_META: String = "skill_pull_contact_source"

static func carry_allowed(monster) -> bool:
	if not is_instance_valid(monster) or monster.dead or monster.caught:
		return false
	if preload("res://scripts/boss_traits.gd").no_launch(monster) or preload("res://scripts/boss_guard.gd").guard_active(monster):
		return false
	return monster.get("armor") == null or int(monster.get("armor")) == 0

static func eagle_matches(carrier, skill_id: int, facing: int) -> bool:
	return is_instance_valid(carrier) and not carrier.ended and not carrier.hostile and int(carrier.spec.id) == 3009 and int(carrier.skill_id) == skill_id and int(carrier.facing) == facing

static func prepare_carried(monster) -> void:
	monster.cancel_attack()
	monster.lie_ticks = 0
	monster.getting_up = false
	monster.rebound = false
	var frames: Array = Game.gameplay_data.monster_motions.get(str(monster.monster_id), {}).get("12", {}).get("frames", [])
	if not frames.is_empty():
		monster.reaction_player.configure(frames)

static func apply_carried_pose(monster, height: float) -> void:
	monster.air_height = maxi(0, int(height))
	monster.air_velocity = 0
	monster.airborne = true
	monster.lie_ticks = 0
	monster.getting_up = false
	monster.rebound = false
	monster.stun = 0
	monster.impact_freeze = 0
	monster.script_movement.reset()
	monster.set_motion("12")

static func lightning_hit(run, monster, skill_id: int, facing: int, damage: int) -> void:
	var spec: Dictionary = Game.slice_data.skills.get(str(skill_id), {})
	if damage <= 0 or int(spec.get("action", 0)) != 316 or int(Game.role().get("career", 0)) != 310 or not carry_allowed(monster):
		return
	if not run.action_player.active or int(run.action_player.action_id) != 316:
		return
	if not monster.has_meta(LIGHTNING_CARRY):
		prepare_carried(monster)
		var relative: Vector2 = monster.position - run.player.position
		var offset: Vector2 = Vector2(clampf(relative.x * facing, 20.0, 90.0) * facing, clampf(relative.y, -20.0, 20.0))
		var lift: float = clampf(float(monster.air_height) - float(run.player.jump_height), 20.0, 40.0)
		monster.set_meta(LIGHTNING_CARRY, {"owner": weakref(run), "offset": offset, "height": lift})
	advance_lightning(run)

static func advance_lightning(run) -> void:
	for monster in run.monsters:
		if not is_instance_valid(monster) or not monster.has_meta(LIGHTNING_CARRY):
			continue
		var state: Dictionary = monster.get_meta(LIGHTNING_CARRY)
		if state.owner.get_ref() != run:
			continue
		if not carry_state_valid(monster, state, false):
			monster.remove_meta(LIGHTNING_CARRY)
			continue
		var target: Vector2 = run.player.position + Vector2(state.offset)
		monster.move_and_collide(target - monster.position)
		apply_carried_pose(monster, float(run.player.jump_height) + float(state.height))

static func release_lightning(run) -> void:
	for monster in run.monsters:
		if is_instance_valid(monster) and monster.has_meta(LIGHTNING_CARRY):
			var state: Dictionary = monster.get_meta(LIGHTNING_CARRY)
			if state.owner.get_ref() == run:
				monster.remove_meta(LIGHTNING_CARRY)

static func carry_state_valid(monster, state: Dictionary, eagle: bool) -> bool:
	if not carry_allowed(monster):
		return false
	var owner = state.owner.get_ref()
	if not is_instance_valid(owner) or not owner.active or owner.status not in ["battle", "complete"] or not is_instance_valid(owner.player):
		return false
	if eagle:
		var carrier = state.carrier.get_ref()
		return is_instance_valid(carrier) and not carrier.ended and not carrier.is_queued_for_deletion() and not carrier.hostile
	return int(Game.role().get("career", 0)) == 310 and int(owner.current_skill) != 0 and owner.action_player.active and int(owner.action_player.action_id) == 316 and owner.action_player.timeline.frame_index <= 10

static func carrier_tick(monster) -> bool:
	for mark in [LIGHTNING_CARRY, EAGLE_MARK]:
		if not monster.has_meta(mark):
			continue
		var state: Dictionary = monster.get_meta(mark)
		if not carry_state_valid(monster, state, mark == EAGLE_MARK):
			monster.remove_meta(mark)
			continue
		monster.advance_source_statuses()
		if monster.dead:
			monster.remove_meta(mark)
			return false
		var height: float = float(state.height)
		if mark == LIGHTNING_CARRY:
			height += float(state.owner.get_ref().player.jump_height)
		apply_carried_pose(monster, height)
		monster.render_frame()
		return true
	return false

const LM_V23_RANGE: float = 280.0 # Four 70-pixel body widths.
const LM_V23_TRAVEL: String = "lm_v23_travelled"

static func limit_lm_v23(attack, previous_position: Vector2) -> bool:
	if int(attack.spec.get("id", 0)) != 70021 or attack.hostile or int(attack.state) != 1:
		return false
	var skill: Dictionary = Game.slice_data.skills.get(str(int(attack.skill_id)), {})
	if int(skill.get("action", 0)) != 125 or int(skill.get("career", 0)) != 120:
		return false
	var travelled: float = float(attack.get_meta(LM_V23_TRAVEL, 0.0))
	var step: Vector2 = attack.position - previous_position
	var remaining: float = maxf(0.0, LM_V23_RANGE - travelled)
	if step.length() >= remaining:
		attack.position = previous_position + step.limit_length(remaining)
		attack.set_meta(LM_V23_TRAVEL, LM_V23_RANGE)
		attack.finish()
		return true
	attack.set_meta(LM_V23_TRAVEL, travelled + step.length())
	return false

static func apply_batch_combat(combat: Dictionary) -> int:
	var changed: int = 0
	for id in combat.catalog.keys():
		var original: Dictionary = combat.catalog[id]
		var action: int = int(original.get("action", 0))
		if action == 504 and int(original.get("career", 0)) == 500:
			var spec: Dictionary = original.duplicate(true)
			spec.hits[1]["interval"] = 4
			combat.catalog[id] = spec
			Game.slice_data.skills[id] = spec
			Game.skill_data.catalog[id] = spec
			var fields: Array = combat.fields[id].duplicate(true)
			fields[1]["damage_only"] = true
			combat.fields[id] = fields
			changed += 1
		elif action == 509 and int(original.get("career", 0)) == 500:
			var fields: Array = combat.fields[id].duplicate(true)
			fields[2]["power_y"] = 3500
			fields[2]["air_power_y"] = 3000
			combat.fields[id] = fields
			changed += 1
	if combat.interacts.has("80004"):
		var disc: Dictionary = combat.interacts["80004"].duplicate(true)
		for frame in disc.motions["1"].frames:
			frame.scripts = frame.scripts.filter(func(script):return str(script.cmd) != "moveActor")
		combat.interacts["80004"] = disc
	if combat.career_motions.get("500", {}).has("509"):
		var motion: Dictionary = combat.career_motions["500"]["509"].duplicate(true)
		# Union of the preceding attack and the rotating spears (offset20, height200).
		motion.frames[40]["areas"] = [{"type":"ac","id":"0","x":"-406","y":"-412","w":"850","h":"580","dz":"150"}]
		combat.career_motions["500"]["509"] = motion
		combat.motions["509"] = motion
		Game.slice_data.motions["509"] = motion
	for id in ["2113102", "2030101"]:
		if not combat.fields.has(id):continue
		var fields: Array = combat.fields[id].duplicate(true)
		for field in fields:
			field["power_y"] = 4500 if id == "2113102" else 2500
			field["air_power_y"] = 3500 if id == "2113102" else 2000
			if id == "2113102":
				field["power_x"] = 1500
				field["air_power_x"] = 1500
		combat.fields[id] = fields
	return changed

static func holy_disc_tick(attack) -> bool:
	if attack.hostile or int(attack.skill_id) / 100 != 504:
		return false
	if int(attack.spec.id) == 80003 and int(attack.state) == 1 and int(attack.age) >= 6:
		# The native projectile finishes onFrameEnd before executing its spawn script.
		attack.run.spawn_interact({"id":80004}, int(attack.skill_id), 1, attack.position, attack.height, int(attack.facing))
		attack.finish()
		return true
	if int(attack.spec.id) != 80004 or int(attack.state) != 2:
		return false
	for monster in attack.run.monsters:
		if not carry_allowed(monster):continue
		var relative: Vector2 = monster.position - attack.position
		if absf(relative.x) > 300.0 or absf(relative.y) > 100.0 or float(monster.air_height) > 400.0:
			continue
		monster.move_and_collide(Vector2(clampf(-relative.x,-4.0,4.0),clampf(-relative.y,-2.0,2.0)))
	return false

const DARK_ARGS: String = "tongling_dark_weapon"
const DARK_STATE: String = "tongling_dark_state"
const DARK_SLOW: String = "9913640"
const DARK_LIFETIME: int = 900
const DARK_WALK: float = 2.6
const DARK_PALETTE: String = "shader_type canvas_item; varying vec4 tint; void vertex(){tint=COLOR;} void fragment(){vec4 c=texture(TEXTURE,UV);float v=max(c.r,max(c.g,c.b));float l=dot(c.rgb,vec3(0.299,0.587,0.114));float mask=smoothstep(0.02,0.12,c.b-max(c.r,c.g))*(1.0-smoothstep(0.65,0.85,c.r/max(c.b,0.001)));vec3 shadow=vec3(0.045,0.035,0.080);vec3 middle=vec3(0.24,0.18,0.34);vec3 light=vec3(0.56,0.49,0.68);vec3 armor=v<0.60?mix(shadow,middle,smoothstep(0.08,0.60,v)):mix(middle,light,smoothstep(0.60,1.0,v));vec3 ink=mix(c.rgb,armor,mask);float neutral=1.0-smoothstep(0.025,0.13,v-min(c.r,min(c.g,c.b)));ink=mix(ink,c.rgb*vec3(0.88,0.84,0.96),neutral*0.80);float green=smoothstep(0.01,0.065,c.g-max(c.r,c.b*0.68))*smoothstep(0.015,0.08,c.g-c.r);vec3 purple=vec3(0.10+0.13*l,0.012+0.028*l,0.19+0.19*l);ink=mix(ink,purple,green);float crystal=clamp(0.65*l+0.35*v,0.0,1.0);vec3 deep=vec3(0.23,0.075,0.38);vec3 gem=vec3(0.60,0.32,0.82);vec3 gleam=vec3(0.92,0.76,1.0);purple=crystal<0.58?mix(deep,gem,smoothstep(0.16,0.58,crystal)):mix(gem,gleam,smoothstep(0.58,0.98,crystal));green=smoothstep(0.025,0.10,c.g-c.r)*smoothstep(0.78,0.92,(c.g-c.r)/max(c.b-c.r,0.001));ink=mix(ink,purple,green);COLOR=vec4(ink,c.a)*tint;}"

static func is_dark_weapon(attack) -> bool:
	return is_instance_valid(attack) and bool(attack.args.get(DARK_ARGS,false))

static func spawn_dark_weapon(run, effect: Dictionary, id: int, index: int) -> bool:
	if int(effect.get("data_1",0)) / 100 != 501 or int(Game.slice_data.skills.get(str(id),{}).get("action",0)) != 136:
		return false
	for previous in run.interact_attacks.duplicate():
		if is_dark_weapon(previous):previous.finish()
	var attack = load("res://scripts/flash/skill_interact.gd").new()
	attack.run = run
	attack.spec = {"id":50101,"type":-41001,"default_state":1,"states":{},"args":[],"blend_mode":"normal","art":{"layers":[]},"motions":{}}
	attack.args = {DARK_ARGS:true}
	attack.skill_id = id
	attack.skill_index = index
	attack.facing = int(run.action_player.facing)
	attack.position = run.world.current_map.safe_position(run.player.position + Vector2(-64*attack.facing,28))
	run.world.current_map.add_child(attack)
	run.interact_attacks.append(attack)
	run.record("summon",{"pack":int(effect.get("data_1",0)),"skill":id,"dark_weapon":true,"body":513000})
	return true

static func dark_ready(attack) -> bool:
	if not is_dark_weapon(attack):return false
	attack.state = 1
	attack.height = 0
	attack.attack_model = attack.run.player_attack_model().duplicate(true)
	attack.hp = maxi(200,int(attack.run.max_hp*0.5))
	attack.art_root = preload("res://scripts/flash/scene_depth.gd").attach_visual(attack)
	var avatar = load("res://scripts/avatar_view.gd").new()
	avatar.name = "DarkAvatar"
	attack.art_root.add_child(avatar)
	avatar.set_process(false)
	var worn: Array = []
	worn.resize(16);worn.fill(0)
	worn[0] = int(Game.equipment_data.birth.get("100",0))
	avatar.configure({"career":130,"career_wear_level":1,"has_join":true,"sublime":false,"equipment":worn,"appearance":{}})
	avatar.external_clock = true
	var shader = Shader.new();shader.code = DARK_PALETTE
	var palette = ShaderMaterial.new();palette.shader = shader
	for part in avatar.parts:part.sprite.material = palette
	attack.special.setup(attack)
	attack.set_meta(DARK_STATE,{"avatar":avatar,"action":0,"phase":0,"lightning_cd":45,"recovery":0,"frame_base":0,"damage_skill":4,"damage_index":0,"hits":{},"last_hits":{}})
	dark_register_slow(attack.run)
	dark_pose(attack,3)
	return true

static func dark_register_slow(run) -> void:
	# Native walkV/runV rates affect movement, without the magnetic-field attack slow.
	var slow: Dictionary = {"attributes":{"duration":"30","id":DARK_SLOW,"type":DARK_SLOW},"events":[{"attributes":{"type":"1"},"effects":[{"data_type":"1","data_1":"1","data_2":"122","data_3":"6000"},{"data_type":"1","data_1":"1","data_2":"1006","data_3":"6000"}]}]}
	run.source_status.data.statuses[DARK_SLOW] = slow
	run.source_status.data.types[DARK_SLOW] = {"type":DARK_SLOW,"classID":"0","effectID":"50013","name":"黑暗兵器·雷斩减速"}
	Game.career_combat.statuses[DARK_SLOW] = slow

static func dark_pose(attack, motion: int) -> void:
	var state: Dictionary = attack.get_meta(DARK_STATE)
	state.avatar.set_motion(motion,attack.facing<0)
	attack.motion = str(motion)

static func dark_walk_to(attack, destination: Vector2, stop: float) -> void:
	var offset: Vector2 = destination-attack.position
	if offset.length() <= stop:
		dark_pose(attack,3)
		return
	if absf(offset.x)>0.01:attack.facing = -1 if offset.x<0 else 1
	var step: Vector2 = offset.normalized()*minf(DARK_WALK,maxf(0.0,offset.length()-stop))
	var map = attack.run.world.current_map
	if map.walkable(attack.position+step):attack.position+=step
	elif map.walkable(attack.position+Vector2(step.x,0)):attack.position.x+=step.x
	elif map.walkable(attack.position+Vector2(0,step.y)):attack.position.y+=step.y
	dark_pose(attack,1)

static func dark_begin_attack(attack, lightning: bool) -> void:
	var state: Dictionary = attack.get_meta(DARK_STATE)
	state.action = 102 if lightning else 4
	state.damage_skill = 10201 if lightning else 4
	state.damage_index = 0 if lightning else int(state.phase)
	state.hits.clear();state.last_hits.clear()
	var motion: int = 102 if lightning else 6
	var full: Array = Game.career_combat.career_motions["100"].get(str(motion),Game.slice_data.motions.get(str(motion),{})).get("frames",[])
	var begin: int = 0
	var end: int = full.size()
	if not lightning:
		var action: Dictionary = Game.flash_actions.action(130,4)
		begin = int(action.states[str(int(state.phase))].frame_index)
		if int(state.phase)<2:end = int(action.states[str(int(state.phase)+1)].frame_index)
		state.phase = (int(state.phase)+1)%3
	else:state.lightning_cd = 90
	state.frame_base = begin
	attack.timeline.configure(full.slice(begin,end))
	dark_pose(attack,motion)
	state.avatar.begin_action_motion(motion,begin,100)
	attack.run.record("dark_weapon_action",{"action":int(state.action),"index":int(state.damage_index)})

static func dark_damage(attack, frame: Dictionary) -> void:
	var state: Dictionary = attack.get_meta(DARK_STATE)
	var id: int = int(state.damage_skill)
	var index: int = int(state.damage_index)
	var hit: Dictionary = Game.slice_data.skills[str(id)].hits[index]
	for monster in attack.run.monsters:
		if not is_instance_valid(monster) or monster.dead or monster.skill_status.has_class(11):continue
		var target_id: int = monster.get_instance_id()
		if int(state.hits.get(target_id,0))>=maxi(1,int(hit.get("multiple",1))):continue
		for area in frame.get("areas",[]):
			if str(area.type)!="ac":continue
			var relative: Vector2 = monster.position-attack.position
			var x: float = relative.x*attack.facing
			var y: float = -float(monster.air_height)
			if x+20<float(area.x) or x-20>float(area.x)+float(area.w) or absf(relative.y)>float(area.dz)+5 or y<float(area.y) or y-float(monster.spec.height)>float(area.y)+float(area.h):continue
			state.hits[target_id] = int(state.hits.get(target_id,0))+1
			var result: Dictionary = preload("res://scripts/flash/damage_calculator.gd").calculate(attack.attack_model,monster.effective_attributes(),hit,attack.facing,-1 if monster.left else 1,monster.attack_tick>=0,attack.run.combat_random.next_float)
			if not bool(result.miss):
				monster.set_meta("damage_critical",bool(result.critical))
				monster.set_meta("damage_skill_id",id)
				attack.run.spawn_context_hit_effect(monster,area,attack.facing,id,index,attack.position,0)
				monster.damage(int(result.damage),Vector2(attack.facing*8,0),false,Game.career_combat.fields[str(id)][index])
				if id==10201 and not monster.dead:monster.apply_source_status(DARK_SLOW)
				attack.run.record_hit(int(result.damage))
				attack.run.record("dark_weapon_hit",{"skill":id,"monster":monster.monster_id,"damage":int(result.damage)})
			break

static func dark_tick(attack) -> bool:
	if not is_dark_weapon(attack):return false
	if attack.ended:return true
	attack.age+=1;attack.state_ticks+=1
	if attack.age>=DARK_LIFETIME or not attack.run.active or attack.run.status=="defeat":
		attack.finish();return true
	var state: Dictionary = attack.get_meta(DARK_STATE)
	state.lightning_cd = maxi(0,int(state.lightning_cd)-1)
	state.recovery = maxi(0,int(state.recovery)-1)
	if int(state.action)!=0:
		var packet: Dictionary = attack.timeline.step()
		if not packet.is_empty():
			state.avatar.control_action_timeline("gotoAndPlay",int(state.frame_base)+int(packet.index))
			state.avatar.advance_action_motion()
			for script in packet.scripts:
				if str(script.cmd)=="createEffect":preload("res://scripts/slice_effect.gd").spawn_bound_interact(attack.run.player,attack,script.args)
				elif str(script.cmd)=="playSound":attack.run.world.audio.play_script(script.args,attack)
			if str(packet.event)=="hit":dark_damage(attack,packet.frame)
			if str(packet.event)=="onFrameEnd":
				state.action=0;state.recovery=8;state.avatar.end_action_motion();state.avatar.external_clock=true;dark_pose(attack,3)
		return true
	var target = null
	var distance: float = INF
	for monster in attack.run.monsters:
		if not is_instance_valid(monster) or monster.dead or monster.is_queued_for_deletion():continue
		var next_distance: float = attack.position.distance_squared_to(monster.position)
		if next_distance<distance:target=monster;distance=next_distance
	attack.tracking_target = target
	if is_instance_valid(target):
		var offset: Vector2 = target.position-attack.position
		if absf(offset.x)>0.01:attack.facing=-1 if offset.x<0 else 1
		if int(state.recovery)==0 and absf(offset.y)<=40 and absf(offset.x)<=180 and int(state.lightning_cd)==0:
			dark_begin_attack(attack,true)
		elif int(state.recovery)==0 and absf(offset.y)<=30 and absf(offset.x)<=110:
			dark_begin_attack(attack,false)
		else:dark_walk_to(attack,target.position,60)
	else:
		var facing: int = -1 if attack.run.player.get_node("Visual").facing_left else 1
		dark_walk_to(attack,attack.run.player.position+Vector2(-64*facing,28),12)
	if int(state.action)==0:
		state.avatar.ticks+=1;state.avatar.update_frames()
	return true

static func dark_enter_room(attack) -> void:
	if not is_dark_weapon(attack):return
	attack.facing=-1 if attack.run.player.get_node("Visual").facing_left else 1
	attack.position=attack.run.player.position+Vector2(-64*attack.facing,28)
	attack.height=0;attack.tracking_target=null
	var state: Dictionary = attack.get_meta(DARK_STATE)
	state.action=0;state.hits.clear();state.avatar.end_action_motion();state.avatar.external_clock=true
	dark_pose(attack,3)
