extends RefCounted

# 受击保护与伤害接管：
# 1) 资源里技能自带的「霸体」状态（status classID 1）真正生效；
# 2) 连续受击达到阈值后短暂进入霸体（连击中断则重新计数）；
# 3) 与 boss_traits 的 super_armor / interruptible 组合。

const PATH: String = "res://data/boss_guard.json"
const DEFAULT_STREAK_HITS: int = 40
const DEFAULT_STREAK_WINDOW: int = 45
const DEFAULT_ARMOR_TICKS: int = 30

const STREAK_KEY: String = "boss_streak"
const STREAK_TICK_KEY: String = "boss_streak_tick"
const ARMOR_KEY: String = "boss_armor_until"

static var _rules: Dictionary = {}
static var _loaded: bool = false


static func _table() -> Dictionary:
	if not _loaded:
		_loaded = true
		if FileAccess.file_exists(PATH):
			var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
			if parsed is Dictionary:
				_rules = parsed
	return _rules


static func _rule(key: String, fallback: int) -> int:
	return int(_table().get(key, fallback))


static func register(monster) -> void:
	if monster == null or not monster.boss:
		return
	var now: int = int(monster.run.ticks)
	var last: int = int(monster.get_meta(STREAK_TICK_KEY, -1000000))
	var streak: int = int(monster.get_meta(STREAK_KEY, 0))
	if now - last > _rule("streak_window_ticks", DEFAULT_STREAK_WINDOW):
		streak = 0
	streak += 1
	monster.set_meta(STREAK_KEY, streak)
	monster.set_meta(STREAK_TICK_KEY, now)
	if streak >= maxi(1, _rule("streak_hits", DEFAULT_STREAK_HITS)):
		monster.set_meta(STREAK_KEY, 0)
		monster.set_meta(ARMOR_KEY, now + maxi(1, _rule("armor_ticks", DEFAULT_ARMOR_TICKS)))


# 资源驱动的霸体（技能状态）或连击触发的限时霸体。
static func armor_active(monster) -> bool:
	if monster == null:
		return false
	if int(monster.run.ticks) < int(monster.get_meta(ARMOR_KEY, 0)):
		return true
	return monster.skill_status.has_class(1)


static func guard_active(monster) -> bool:
	if monster == null:
		return false
	if preload("res://scripts/boss_traits.gd").super_armor(monster):
		return true
	return armor_active(monster)


# 命中时先登记连击，再决定是否由本模块接管这次伤害结算。
static func take_over(monster) -> bool:
	if monster == null:
		return false
	register(monster)
	if guard_active(monster):
		return true
	return preload("res://scripts/boss_traits.gd").interruptible(monster)


static func apply_damage(monster, value: int, knockback: Vector2, launch: bool, reaction: Dictionary) -> void:
	if monster == null or monster.dead:
		return
	var old_hp: int = int(monster.hp)
	monster.hp = maxi(0, int(monster.hp) - value)
	monster.run.world.get_node("HUDOverlay").show_monster_hit(monster, old_hp)
	if guard_active(monster):
		monster.stun = 0
		monster.impact_freeze = 0
	else:
		monster.cancel_attack()
		monster.stun = 18 if launch else 9
		monster.set_motion("11")
		monster.animation_tick = 0
		monster.animation_frame_ref = -1
		if reaction.is_empty():
			monster.move_and_collide(knockback)
		else:
			monster.apply_reaction(reaction, -1 if knockback.x < 0 else 1)
	# 弹字用真实扣血量：血只剩一点时打出的溢出伤害不该照实弹出来。
	monster.run.world.get_node("HUDOverlay").damage_popup(old_hp - int(monster.hp), monster.position + Vector2(0, -50 - int(monster.air_height)), false, bool(monster.get_meta("damage_critical", false)))
	monster.set_meta("damage_critical", false)
	monster.run.world.audio.play_package(int(Game.presentation_data.audio.hurt_sounds["0"]))
	if int(monster.hp) == 0:
		monster.cancel_attack()
		monster.dead = true
		monster.collision_layer = 0
		monster.set_motion("12")
		if not monster.airborne:
			monster.begin_death_wait()
		monster.run.monster_defeated(monster)
	monster.render_frame()


# Continuous cutting damage preserves the target's running action and reaction.
static func damage_only(monster, value: int, reaction: Dictionary) -> bool:
	if not bool(reaction.get("damage_only", false)):
		return false
	if monster.dead:
		return true
	var training: bool = monster.get("infinite_hp") != null
	var critical: bool = bool(monster.get_meta("damage_critical", false))
	var skill_id: int = int(monster.get_meta("damage_skill_id", 0))
	if monster.has_meta("damage_skill_id"):
		monster.remove_meta("damage_skill_id")
	if training:
		value = maxi(1, int(value * (1.0 - float(monster.damage_reduction))))
	var old_hp: int = int(monster.hp)
	monster.hp = int(monster.max_hp) if training and monster.infinite_hp else maxi(0, int(monster.hp) - value)
	if training:
		monster.run.training_damage(skill_id, value, critical)
	var hud = monster.run.world.get_node("HUDOverlay")
	hud.show_monster_hit(monster, old_hp)
	hud.damage_popup(maxi(0, old_hp - int(monster.hp)), monster.position + Vector2(0, -50 - monster.air_height), false, critical)
	monster.set_meta("damage_critical", false)
	if monster.hp == 0:
		monster.cancel_attack()
		monster.dead = true
		monster.collision_layer = 0
		monster.set_motion("12")
		if not monster.airborne:
			monster.begin_death_wait()
		monster.run.monster_defeated(monster)
		monster.render_frame()
	return true


# Slow only the damage timeline: field lifetime, movement and visuals keep real time.
static func field_step(interact) -> Dictionary:
	return interact.timeline.step()

static func is_field_slow(id: String) -> bool:
	return int(id) / 100 == 114

static func field_attack_rate(monster) -> float:
	var rate: float = 1.0
	for id in monster.skill_status.active:
		if not is_field_slow(str(id)):
			continue
		var spec: Dictionary = monster.skill_status.data.statuses.get(str(id), {})
		var effects: Array = []
		for event in spec.get("events", []):
			if int(event.attributes.get("type", 1)) == 1:effects.append_array(event.effects)
		if spec.has("effects"):effects.append_array(spec.effects)
		for effect in effects:
			if int(effect.get("data_type", 0)) == 1 and int(effect.get("data_2", 0)) == 122:
				rate = minf(rate, float(effect.get("data_3", 10000)) / 10000.0)
	return clampf(rate, 0.05, 1.0)

# Apply the slow to the actual attack timeline, including attacks already in progress.
static func field_attack_step(monster) -> bool:
	var rate: float = field_attack_rate(monster)
	if rate >= 1.0:
		if monster.has_meta("tongling_attack_clock"):monster.remove_meta("tongling_attack_clock")
		return true
	var clock: float = float(monster.get_meta("tongling_attack_clock", 0.0)) + rate
	var advance: bool = clock + 0.000001 >= 1.0
	monster.set_meta("tongling_attack_clock", maxf(0.0, clock - 1.0) if advance else clock)
	return advance

static func apply_magnetic_fields(combat: Dictionary) -> int:
	var changed: int = 0
	for id in combat.catalog:
		var spec: Dictionary = combat.catalog[id]
		var action: int = int(spec.get("action", 0))
		if int(spec.get("career", 0)) != 130 or action not in [131, 132, 145]:
			continue
		var fields: Array = combat.fields[id].duplicate(true)
		if action in [132, 145]:
			for field in fields:field["damage_only"] = true
		else:
			for field in fields:
				var functions: PackedStringArray = []
				for key in str(field.functions[0]).split(",", false):
					var function: Dictionary = combat.functions.get(key, {})
					if function.get("effects", []).any(func(effect):return int(effect.get("data_type", 0)) == 4 and int(effect.get("data_1", 0)) == 7001):
						var clone: Dictionary = function.duplicate(true)
						key = "990" + str(id)
						clone.attributes["id"] = key
						clone.attributes["p"] = "5000"
						for effect in clone.effects:
							if int(effect.get("data_type",0))==4 and int(effect.get("data_1",0))==7001:effect.data_1="99131050"
						combat.functions[key] = clone
					functions.append(key)
				field.functions[0] = ",".join(functions)
			var description: PackedStringArray = str(spec.get("description2", "")).split("<br/>")
			for index in description.size():
				if "冰冻几率" in description[index]:description[index] = "冰冻几率50%"
			spec.description2 = "<br/>".join(description)
		combat.fields[id] = fields
		changed += 1
	return changed
