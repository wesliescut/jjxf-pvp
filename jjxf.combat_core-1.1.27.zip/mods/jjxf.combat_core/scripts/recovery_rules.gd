extends RefCounted

# 倒地时长同时就是「按 C 快速起身」的按键窗口。用户反馈窗口太短、经常按不出来，
# 这里从 30 tick（1 秒）延长到 60 tick（2 秒），判定窗口正好翻倍。
const DOWN_TICKS: int = 60
const QUICK_COOLDOWN: int = 150
const QUICK_ALPHA: float = 0.45
const CLOCK_KEY: String = "quick_recovery_cooldown"
const QUICK_KEY: String = "quick_recovery_active"
const GRACE_KEY: String = "quick_recovery_grace"
const GRACE_QUICK_KEY: String = "quick_recovery_grace_visible"
const QUICK_GRACE: int = 45
# 起身段总时长预算（tick）。动作 15 = 躺下(0-1) + 起身(2-尾)，
# 原来完全靠最后一帧的 onFrameEnd 事件收尾：动作表被裁、换职业、
# 时间轴刚好停在长帧上时事件永远不来，action_locked 就一直挂着，
# 只能等 slice_run.guard_stuck_action() 在 90 tick（正好 3 秒）后强杀。
# 这就是「倒地起身后 3 秒放不出技能、只能左右走」。改成按帧表算预算，到点必收尾。
const RISE_KEY: String = "rise_budget"
const RISE_FINAL_KEY: String = "rise_final_hold"

static func reaction_for(run: Node) -> Variant:
	var training = run.get("player_reaction")
	if training != null:
		return training
	return run.get("hit_reaction")


static func player_protected(run: Node) -> bool:
	var reaction = reaction_for(run)
	if reaction == null:
		return false
	if reaction.state == "get_up" and bool(reaction.get_meta(QUICK_KEY, false)):
		return true
	return int(reaction.get_meta(GRACE_KEY, 0)) > 0

static func refresh_alpha(run: Node) -> void:
	if not is_instance_valid(run.player):
		return
	var alpha: float = run.source_status.body_alpha()
	var reaction = reaction_for(run)
	var grace: bool = reaction != null and int(reaction.get_meta(GRACE_KEY,0)) > 0
	var quick: bool = reaction != null and ((grace and bool(reaction.get_meta(GRACE_QUICK_KEY,false))) or (reaction.state == "get_up" and bool(reaction.get_meta(QUICK_KEY,false))))
	if quick:alpha = minf(alpha, QUICK_ALPHA)
	run.player.get_node("Visual").modulate.a = alpha
	for name in ["Name","Shadow"]:
		var part = run.player.get_node_or_null(name)
		if part != null:part.modulate.a = 1.0

static func frames_rise_budget(frames: Array) -> int:
	## 起身段（第 2 帧到最后一帧）总 tick 数 + 一点余量。
	## 帧表不规整时（<3 帧）给 6 tick 兜底，保证一定能站起来。
	if frames.size() <= 2:
		return 6
	var budget: int = 0
	for index in range(2, frames.size()):
		budget += maxi(1, int(frames[index].get("ticks", 1)))
	return budget + 4


static func player_reset(reaction: RefCounted) -> void:
	reaction.set_meta(RISE_KEY, 0)
	reaction.set_meta(RISE_FINAL_KEY, 0)
	reaction.set_meta(QUICK_KEY, false)
	reaction.set_meta(GRACE_KEY, 0)
	reaction.set_meta(GRACE_QUICK_KEY, false)
	if is_instance_valid(reaction.run) and is_instance_valid(reaction.run.player):
		refresh_alpha(reaction.run)

static func hold_fatal_lie_pose(reaction: RefCounted) -> void:
	if reaction.state != "lie" or not is_instance_valid(reaction.run) or not reaction.run.has_meta("jjxf_fatal_pending"):
		return
	var player = reaction.run.player
	if not is_instance_valid(player):
		return
	player.action_locked = true
	reaction.movie.timeline.playing = false
	var visual = player.get_node("Visual")
	var changed: bool = false
	if not bool(visual.external_clock) or not bool(visual.action_parts_clock) or int(visual.motion) != 15:
		visual.begin_action_motion(15, 1)
		changed = true
	for part in visual.parts:
		if not part.has("clock") or part.clock.frames.is_empty():
			continue
		var clock = part.clock
		var frame_index: int = mini(1, clock.frames.size() - 1)
		var frame: Dictionary = clock.frames[frame_index]
		var opacity: float = float(frame.get("alpha", 1.0)) + float(frame.get("delta_alpha", 0.0))
		if str(frame.get("path", "")).is_empty() or opacity <= 0.05:
			var first: Dictionary = clock.frames[0]
			var first_opacity: float = float(first.get("alpha", 1.0)) + float(first.get("delta_alpha", 0.0))
			if not str(first.get("path", "")).is_empty() and first_opacity > opacity:
				frame_index = 0
		if clock.frame_index != frame_index:
			clock.goto_frame(frame_index)
			changed = true
		if clock.elapsed < 1:
			clock.elapsed = 1
			changed = true
		if clock.playing:
			clock.playing = false
			changed = true
	if visual.modulate.a != 1.0:
		visual.modulate.a = 1.0
	if changed:
		visual.update_frames()

static func player_lie(reaction: RefCounted) -> void:
	if reaction.state in ["lie", "get_up"]:
		return
	reaction.state = "lie"
	reaction.remaining = DOWN_TICKS
	reaction.height = 0
	reaction.velocity = 0
	reaction.freeze = 0
	reaction.rebound = true
	reaction.movement.reset()
	reaction.run.player.action_locked = true
	reaction.play_motion(15)
	reaction.render_height()
	hold_fatal_lie_pose(reaction)

static func player_rise(reaction: RefCounted, quick: bool) -> void:
	reaction.state = "get_up"
	reaction.remaining = 0
	reaction.freeze = 0
	reaction.height = 0
	reaction.velocity = 0
	reaction.movement.reset()
	reaction.matches.clear()
	reaction.set_meta(QUICK_KEY, quick)
	reaction.set_meta(RISE_FINAL_KEY, 0)
	if quick:
		reaction.set_meta(CLOCK_KEY, QUICK_COOLDOWN)
	# Resume each career's own existing get-up sequence.
	reaction.movie.timeline.goto_frame(2)
	reaction.run.player.get_node("Visual").control_action_timeline("gotoAndPlay", 2)
	# 预算兜底：即使 onFrameEnd 永远不来，这里到点也会 finish()。
	reaction.set_meta(RISE_KEY, frames_rise_budget(reaction.movie.timeline.frames))
	refresh_alpha(reaction.run)

static func player_advance(reaction: RefCounted) -> bool:
	var cooldown: int = int(reaction.get_meta(CLOCK_KEY, 0))
	if cooldown > 0:
		reaction.set_meta(CLOCK_KEY, cooldown - 1)
	var grace: int = int(reaction.get_meta(GRACE_KEY, 0))
	if grace > 0:
		reaction.set_meta(GRACE_KEY, grace - 1)
	if reaction.state.is_empty():
		return false
	if reaction.run.status not in ["battle", "complete"]:
		reaction.reset()
		if reaction.run.status == "defeat":
			reaction.run.player.action_locked = true
		return true
	if player_launch_tick(reaction):
		return true
	if reaction.state not in ["lie", "get_up"]:
		return false
	# Hits and hitstop cannot restart or pause a completed knockdown.
	reaction.freeze = 0
	if reaction.state == "lie" and not reaction.run.has_meta("jjxf_fatal_pending"):
		reaction.remaining -= 1
		if reaction.remaining <= 0:
			player_rise(reaction, false)
	var packet: Dictionary = {}
	if reaction.state != "lie" or not reaction.run.has_meta("jjxf_fatal_pending"):
		packet = reaction.movie.advance()
	if reaction.state == "get_up":
		reaction.set_meta(RISE_KEY, maxi(0, int(reaction.get_meta(RISE_KEY, 0)) - 1))
	# 倒地动作 15 是「躺下(0-1) + 起身(2-尾)」的一整段：倒地计时（DOWN_TICKS=60）
	# 比整段动作（13~19 tick）长，时间轴播到尾巴会自己 loop 回第 0 帧 —— 表现就是
	# 躺在地上反复「站起来又倒下」上下抖动。这里把时间轴钉在躺姿那一帧（第 1 帧），
	# 等 remaining 归零、player_rise() 再把 playing 打开从第 2 帧起身。
	if reaction.state == "lie":
		var lie_timeline = reaction.movie.timeline
		if int(lie_timeline.frame_index) > 1:
			lie_timeline.goto_frame(1)
			lie_timeline.playing = false
			if is_instance_valid(reaction.run) and is_instance_valid(reaction.run.player):
				reaction.run.player.get_node("Visual").control_action_timeline("gotoAndStop", 1, true)
		elif int(lie_timeline.frame_index) == 1:
			# 每 tick 都确认一次「停在第 1 帧」：只要有一次被 advance/外部重配带跑，
			# 下一 tick 立刻按回去，避免躺姿和起身帧来回切（上下抖动）。
			lie_timeline.playing = false
	hold_fatal_lie_pose(reaction)
	var rise_done: bool = false
	if reaction.state == "get_up":
		var final_hold: int = int(reaction.get_meta(RISE_FINAL_KEY, 0))
		if final_hold > 0:
			final_hold -= 1
			reaction.set_meta(RISE_FINAL_KEY, final_hold)
			rise_done = final_hold == 0
		elif packet.get("event", "") == "onFrameEnd":
			reaction.set_meta(RISE_FINAL_KEY, 6)
			reaction.movie.timeline.playing = false
			reaction.run.player.get_node("Visual").control_action_timeline("gotoAndStop", int(reaction.movie.timeline.frame_index))
		elif int(reaction.get_meta(RISE_KEY, 0)) <= 0:
			rise_done = true
	if rise_done:
		var quick: bool = bool(reaction.get_meta(QUICK_KEY,false))
		reaction.finish()
		# 普通起身不额外无敌；仅主动快速起身保留短暂保护。
		reaction.set_meta(GRACE_KEY, QUICK_GRACE if quick else 0)
		reaction.set_meta(GRACE_QUICK_KEY, quick)
		if is_instance_valid(reaction.run):
			refresh_alpha(reaction.run)
		return true
	reaction.render_height()
	return true

static func input_recovery(run: Node, event: InputEvent) -> bool:
	if run.has_meta("jjxf_fatal_pending"):
		return true
	if not run.active or run.status not in ["battle", "complete"] or not run.player.input_enabled:
		return false
	if not event is InputEventKey or not event.pressed or event.echo:
		return false
	if event.physical_keycode != KEY_C and event.keycode != KEY_C and not event.is_action_pressed("jump"):
		return false
	var reaction = reaction_for(run)
	if reaction == null or reaction.state not in ["lie", "get_up"]:
		return false
	if reaction.state == "lie" and int(reaction.get_meta(CLOCK_KEY, 0)) <= 0:
		player_rise(reaction, true)
	# Consume the key during knockdown, including while on cooldown.
	return true

static func receive_hit(run: Node, damage: int, hit: Dictionary, direction: int) -> void:
	if run.has_meta("jjxf_fatal_pending"):
		return
	if preload("res://scripts/block_rules.gd").invulnerable_active(run):
		return
	if run.status != "battle" or run.invincible > 0 or run.source_status.has_class(11) or player_protected(run):
		return
	preload("res://scripts/block_rules.gd").refresh(run)
	run.hurt_player(damage)
	if run.status == "defeat":
		run.player_reaction.reset()
		run.player.action_locked = true
		return
	if preload("res://scripts/block_rules.gd").protects_hit(run, hit):
		return
	# 技能施法 1 秒内的隐藏霸体：伤害已经由上面的 hurt_player 吃掉，
	# 这里只是不再进入受击硬直/浮空（训练场走的是这条入口，必须和 handle_hit 一致）。
	if run.has_method("skill_guard_active") and run.skill_guard_active():
		return
	if not run.training_active or bool(run.settings.player_hit_reactions):
		run.invincible = 0
		run.player_reaction.accept(hit, direction)
		if run.training_active and bool(run.settings.player_invincible):
			run.world.audio.play_package(int(Game.presentation_data.audio.hurt_sounds["0"]))

static func monster_down(monster: Node) -> bool:
	return not monster.dead and (monster.lie_ticks > 0 or monster.getting_up)

static func monster_lie(monster: Node) -> void:
	if monster.dead or monster_down(monster):
		return
	# 被击倒时必须现形：西雅公主这类「隐身突进」技能用 targetHideView 把模型藏起来，
	# 若在隐身期间被打倒，走的是受击分支、不会执行技能的 show，模型会永久隐身在场上。
	monster.view_hidden = false
	monster.set_motion("15")
	monster.lie_ticks = DOWN_TICKS
	monster.getting_up = false
	monster.stun = 0
	monster.impact_freeze = 0
	monster.air_height = 0
	monster.air_velocity = 0
	monster.airborne = false
	monster.script_movement.reset()
	monster.animation_frame_ref = -1
	monster.cast_height = 0
	monster.cast_velocity = 0
	# 动作表可能没有 15（不同副本的怪物表不一样）——硬索引会抛错中断整个函数，
	# 结果就是「lie_ticks 设了但时间轴还是上一套动作」，渲染层于是循环播放。
	var lie_frames: Array = Game.gameplay_data.monster_motions.get(str(monster.monster_id), {}).get("15", {}).get("frames", [])
	if not lie_frames.is_empty():
		monster.reaction_player.configure(lie_frames)
	else:
		monster.set_motion("15")
	monster.set_meta(RISE_KEY, frames_rise_budget(lie_frames))

static func monster_advance(monster: Node) -> bool:
	if not monster_down(monster):
		return false
	monster.advance_source_statuses()
	if monster.dead:
		monster.advance_death()
		monster.render_frame()
		return true
	monster.impact_freeze = 0
	monster.stun = 0
	monster.animation_tick += 1
	if monster.lie_ticks > 0:
		monster.lie_ticks -= 1
		if monster.lie_ticks == 0:
			monster.getting_up = true
			monster.reaction_player.timeline.goto_frame(2)
	var packet: Dictionary = monster.reaction_player.advance()
	if not packet.is_empty():
		monster.animation_frame_ref = int(packet.index)
	# 与玩家同一套「倒地钉帧」：怪物倒地计时同样长于 15 号动作，不钉住会循环抽搐。
	if not monster.getting_up and int(monster.lie_ticks) > 0:
		var lie_timeline = monster.reaction_player.timeline
		if int(lie_timeline.frame_index) > 1:
			lie_timeline.goto_frame(1)
			lie_timeline.playing = false
			monster.animation_frame_ref = 1
		elif int(lie_timeline.frame_index) == 1 and int(lie_timeline.remaining) <= 0:
			lie_timeline.playing = false
	if monster.getting_up:
		var rise_left: int = maxi(0, int(monster.get_meta(RISE_KEY, 0)) - 1)
		monster.set_meta(RISE_KEY, rise_left)
		if packet.get("event", "") == "onFrameEnd" or rise_left <= 0:
			monster.getting_up = false
			monster.rebound = false
			monster.airborne = false
			monster.air_height = 0
			monster.air_velocity = 0
			monster.set_motion("3")
	monster.render_frame()
	return true

const CD_SHAKE: String = "cooldown_reject_shake"

const PLAYER_ARC: String = "player_hit_parabola"
const PLAYER_LAUNCH_SPEED: float = 0.6
const PLAYER_LAUNCH_HEIGHT: float = 1.2
const DAMAGE_ARMOR_ID: String = "9900701"
const DAMAGE_ARMOR_HISTORY: String = "recent_damage_armor_history"
const DAMAGE_ARMOR_WINDOW: int = 45
const DAMAGE_ARMOR_TICKS: int = 60

static func reject_cooldown(run, requested: int) -> bool:
	if not run.active or run.status not in ["battle","complete"] or not is_instance_valid(run.player):
		return false
	var id: int = Game.normal_skill_id() if requested == 4 else requested
	if not Game.slice_data.skills.has(str(id)) or int(run.cooldowns.get(Game.skill_cooldown_key(id),0)) <= 0:
		return false
	if run.current_skill != 0:
		var current: Dictionary = Game.slice_data.skills.get(str(int(run.current_skill)),{})
		if int(current.get("action",-1)) == int(Game.slice_data.skills[str(id)].action):return false
	var visual = run.player.get_node("Visual")
	if not run.has_meta(CD_SHAKE):
		run.set_meta(CD_SHAKE,{"ticks":8,"base":float(visual.position.x)})
	return true

static func advance_feedback(run) -> void:
	if not run.has_meta(CD_SHAKE) or not is_instance_valid(run.player):return
	var state: Dictionary = run.get_meta(CD_SHAKE)
	state.ticks = int(state.ticks) - 1
	var visual = run.player.get_node("Visual")
	visual.position.x = float(state.base) + (3.0 if int(state.ticks) % 2 else -3.0) if int(state.ticks) > 0 else float(state.base)
	if int(state.ticks) <= 0:run.remove_meta(CD_SHAKE)

static func recoil_power(hit: Dictionary, airborne: bool, model: Dictionary) -> int:
	var rate: float = float(model.get("beHurtBack",1.0))
	if rate <= 0.0:return 0
	var power: int = int(hit.get("air_power_x",0) if airborne else hit.get("power_x",0))
	return clampi(int(absf(float(power)) * rate),1500,2000)

static func persistent_room_follower(run, item) -> bool:
	if not is_instance_valid(item) or item.ended or item.hostile or item.is_queued_for_deletion():return false
	var kind: int = int(item.spec.type)
	if preload("res://scripts/skill_pull.gd").is_dark_weapon(item):return true
	if kind in [20001,20003,20005]:return true
	if int(item.args.get("bDisappearOnOwnerActionEnd",0)) == 1:return false
	var follows: bool = (is_instance_valid(item.follower) and item.follower == run.player) or kind == 14
	if not follows:return false
	if kind == 40002:return true
	if kind not in [5,14]:return false
	for state in item.spec.get("states",{}).values():
		var trigger: Dictionary = state.get("trigger",{})
		var args: Array = trigger.get("args",[])
		if str(trigger.get("type","")) == "gOnInterval" and not args.is_empty() and int(args[0]) >= 30:
			# Short casting attachments (for example seal's 42-tick light ball)
			# must end with their cast rather than follow the room transfer.
			return not str(item.spec.get("exclude","")).is_empty() or int(args[0]) >= 90
	return kind == 14 and item.spec.get("args",[]).size() >= 3

static func restore_room_buffs(run, followers: Array) -> void:
	for item in followers:
		if not is_instance_valid(item) or item.ended:continue
		if preload("res://scripts/skill_pull.gd").is_dark_weapon(item):preload("res://scripts/skill_pull.gd").dark_enter_room(item)
		if is_instance_valid(item.follower) and item.follower == run.player:
			item.position = run.player.position + Vector2(item.follow_offset.x * item.facing,item.follow_offset.z)
			item.height = run.player.jump_height + item.follow_offset.y
		if int(item.spec.type) == 14:item.track.clear()
	# The active clocks are retained; recreate only visuals cleared with the old room.
	for visual in run.source_status.visuals.values():
		if is_instance_valid(visual):visual.queue_free()
	run.source_status.visuals.clear()
	run.source_status.sync_visuals(run.player)
	refresh_alpha(run)


# ---------------------------------------------------------------- 伤害护甲
# 45 tick 内累计掉血超过最大生命 15% 时，获得 20 tick 护甲（霸体 + 发光）。
# 与 fx 的差异：发光走我们自己的 scripts/armor_glow.gd（已经会读 armor_active）。

static func damage_armor_active(run) -> bool:
	return run != null and run.source_status.active.has(DAMAGE_ARMOR_ID)


static func register_damage_armor(run, hp_before: int) -> void:
	var loss: int = maxi(0, hp_before - int(run.hp))
	if int(run.hp) <= 0:
		reset_damage_armor(run)
		return
	if loss <= 0 or not run.active or run.status != "battle" or int(run.max_hp) <= 0:
		return
	var now: int = int(run.ticks)
	var career: int = int(Game.role().get("career", 0))
	var history: Dictionary = run.get_meta(DAMAGE_ARMOR_HISTORY, {})
	if history.is_empty() or int(history.career) != career or int(history.last_tick) > now or str(history.session) != str(run.run_id):
		history = {"career": career, "last_tick": now, "session": str(run.run_id), "hits": []}
	var kept: Array = []
	var total: int = loss
	for hit in history.hits:
		if now - int(hit.tick) <= DAMAGE_ARMOR_WINDOW:
			kept.append(hit)
			total += int(hit.loss)
	kept.append({"tick": now, "loss": loss})
	history.hits = kept
	history.last_tick = now
	run.set_meta(DAMAGE_ARMOR_HISTORY, history)
	# 用整数比较，恰好 15% 不算触发。
	if total * 100 <= int(run.max_hp) * 15:
		return
	run.source_status.data.statuses[DAMAGE_ARMOR_ID] = {"attributes": {"id": DAMAGE_ARMOR_ID, "type": "13", "duration": "20"}, "events": []}
	run.source_status.add(DAMAGE_ARMOR_ID)
	# 一次达标消耗一组累计伤害；新的达标组可以刷新持续时间，但不会重复计算旧伤害。
	history.hits = []
	var reaction = reaction_for(run)
	if reaction != null and str(reaction.state) in ["hurt", "stiff"]:
		reaction.finish()
	preload("res://scripts/armor_glow.gd").refresh_player(run)
	run.record("damage_armor", {"damage": total, "max_hp": int(run.max_hp), "duration": DAMAGE_ARMOR_TICKS, "window": DAMAGE_ARMOR_WINDOW})


static func reset_damage_armor(run) -> void:
	if run == null:
		return
	if run.has_meta(DAMAGE_ARMOR_HISTORY):
		run.remove_meta(DAMAGE_ARMOR_HISTORY)
	run.source_status.active.erase(DAMAGE_ARMOR_ID)
	preload("res://scripts/armor_glow.gd").refresh_player(run)


# ---------------------------------------------------------------- 玩家击飞
# 保留原版起跳/顶点/落地时间，只把抛物线补上水平位移与更高的弧线。

static func player_launch_begin(reaction, direction: int) -> void:
	if reaction.state != "float":
		return
	var height: float = float(reaction.height)
	var gravity: float = 5.0 / 6.0
	var duration: float = (10.0 + sqrt(100.0 + 2.0 * gravity * height)) / gravity
	reaction.movement.reset()
	reaction.set_meta(PLAYER_ARC, {"height": height, "ticks": 0, "duration": duration, "direction": -1 if direction < 0 else 1, "distance": 48.0, "movie_clock": 0.0})


static func player_launch_tick(reaction) -> bool:
	if not reaction.has_meta(PLAYER_ARC):
		return false
	if reaction.state != "float":
		reaction.remove_meta(PLAYER_ARC)
		return false
	if reaction.freeze > 0:
		reaction.freeze -= 1
		return true
	var arc: Dictionary = reaction.get_meta(PLAYER_ARC)
	var before: float = minf(float(arc.ticks) / float(arc.duration), 1.0)
	arc.ticks += (2.0 if float(arc.ticks) < 12.0 else 3.0) * PLAYER_LAUNCH_SPEED
	var after: float = minf(float(arc.ticks) / float(arc.duration), 1.0)
	reaction.run.player.move_and_collide(Vector2(float(arc.direction) * float(arc.distance) * (after - before), 0))
	var time: float = minf(float(arc.ticks), float(arc.duration))
	var extra: float = 60.0 * (PLAYER_LAUNCH_HEIGHT - 1.0)
	var span: float = 12.0 if time <= 12.0 else float(arc.duration) - 12.0
	var phase: float = (time - 12.0) / span
	reaction.height = maxi(0, int(round(float(arc.height) + 10.0 * time - 5.0 / 12.0 * time * time + extra * (1.0 - phase * phase))))
	reaction.velocity = int((10.0 - 5.0 / 6.0 * time - 2.0 * extra * (time - 12.0) / (span * span)) * 100.0 * (3.0 if time > 12.0 else 2.0) * PLAYER_LAUNCH_SPEED)
	# Fatal launch uses this custom arc and returns before normal float advance.
	# Synchronize the picture after updating the arc's actual velocity.
	if reaction.has_method("advance_float_pose"):
		reaction.advance_float_pose()
		reaction.hold_float_pose()
	elif reaction.has_method("advance_training_float_pose"):
		reaction.advance_training_float_pose()
		reaction.hold_training_float_pose()
	if after >= 1.0:
		reaction.remove_meta(PLAYER_ARC)
		if reaction.get("knockdown") != null and not reaction.knockdown:
			reaction.finish()
		else:
			player_lie(reaction)
	else:
		arc.movie_clock = float(arc.movie_clock) + PLAYER_LAUNCH_SPEED
		while float(arc.movie_clock) >= 1.0 - 0.000001:
			arc.movie_clock = maxf(0.0, float(arc.movie_clock) - 1.0)
			reaction.movie.advance()
	reaction.render_height()
	return true
