extends RefCounted

# 玩家受击反应：受伤 -> 恢复；击倒力足够时 -> 浮空 -> 倒地 -> 起身
# 动作素材来自 data/training_reactions.json 的 11 受伤 / 12 受伤浮空 / 15 倒地+起身
# 倒地时长、C 键快速起身、无敌与半透明由 recovery_rules.gd 统一管理

const RULES_PATH: String = "res://data/player_knockdown.json"

var run: Node
var state: String = ""
var remaining: int = 0
var freeze: int = 0
var height: int = 0
var velocity: int = 0
var rebound: bool = false
var knockdown: bool = false
var movement = preload("res://scripts/flash/script_movement.gd").new()
var movie = preload("res://scripts/flash/motion_script_player.gd").new()
var data: Dictionary = {}
var matches: Array = []
var rules: Dictionary = {}
# 受击/浮空/倒地动作是套在 Visual 的外部时钟上放的（begin_action_motion）。
# 这是独占资源：开了就必须由这里关掉，否则角色会永远停在受击那一帧。
var owns_clock: bool = false
# These only choose the picture; airborne height and hit physics remain unchanged.
var float_pose_index: int = 2
var float_launch_speed: int = 1

# 浮空/倒地连击保护（参考 DNF 浮空保护 + 改编的倒地保护）：
# 被同一套连招连续打超过 CHAIN_LIMIT 次后，给一段时间「伤害照吃、但不再吃任何硬直」，
# 期间玩家从浮空/受击状态直接落地倒地、走正常起身流程。
const CHAIN_LIMIT: int = 2
const CHAIN_RESET_MS: int = 5000
const CHAIN_GUARD_MS: int = 2600
var chain_count: int = 0
var chain_last_ms: int = 0
var chain_guard_until: int = 0


func configure(session: Node) -> void:
	run = session
	data = Game.player_reaction_data
	rules = _load_rules()
	movie.frame_ready.connect(on_frame_ready)
	movie.timeline_command.connect(on_timeline_command)
	movie.script_requested.connect(on_script)


static func _load_rules() -> Dictionary:
	var defaults: Dictionary = {
		"knockdown_power_y": 2000,
		"knockdown_air_power_y": 1000,
		"hurt_ticks": 8,
	}
	if not FileAccess.file_exists(RULES_PATH):
		return defaults
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(RULES_PATH))
	if not parsed is Dictionary:
		return defaults
	for key in defaults:
		if not parsed.has(key):
			parsed[key] = defaults[key]
	return parsed


func advance_float_pose() -> void:
	if state != "float" or rebound or float_pose_index >= 4:
		return
	var threshold: int = maxi(1, int(float_launch_speed * 0.2))
	if velocity <= -threshold:
		float_pose_index = 4
	elif velocity <= threshold and float_pose_index < 3:
		float_pose_index = 3


func hold_float_pose() -> void:
	if state != "float" or not is_instance_valid(run) or not is_instance_valid(run.player):
		return
	# 玩家普通移动更新仅在 action_locked=false 时把 Visual 改回站姿。
	run.player.action_locked = true
	var vis = run.player.get_node_or_null("Visual")
	if vis == null:
		return
	# Keep exclusive ownership even when another action resets Visual mid-air.
	if not bool(vis.get("external_clock")) or not bool(vis.get("action_parts_clock")) or int(vis.get("motion")) != 12:
		vis.begin_action_motion(12, float_pose_index)
	for part in vis.parts:
		if not part.has("clock"):
			continue
		var clock = part.clock
		var last: int = int(clock.frames.size()) - 1
		if last < 0:
			continue
		clock.goto_frame(mini(float_pose_index, last))
		clock.playing = false
	vis.update_frames()


func on_frame_ready(packet: Dictionary) -> void:
	if state == "float":
		hold_float_pose()
		return
	var vis = run.player.get_node("Visual")
	var index: int = int(packet.get("index", 0))
	for part in vis.parts:
		if not part.has("clock"):
			continue
		var clock = part.clock
		var last: int = int(clock.frames.size()) - 1
		if last < 0:
			continue
		clock.goto_frame(clampi(index, 0, last))
		clock.playing = false
	vis.update_frames()


func on_timeline_command(command: String, index: int) -> void:
	if state == "float":
		return
	run.player.get_node("Visual").control_action_timeline(command, index, true)


func on_script(command: String, args: Dictionary) -> void:
	if command == "acceptVKey":
		if int(args.get("clear", 0)) == 1:
			matches.clear()
		var matcher = preload("res://scripts/flash/vkey_match.gd").new()
		matcher.configure(args)
		if not matcher.steps.is_empty():
			matches.append(matcher)
	elif command == "stop":
		movie.timeline.playing = false
		run.player.get_node("Visual").control_action_timeline("stop", -1)
	elif command == "playSound":
		run.world.audio.play_script(args, run.player)


func reset(reset_player: bool = true) -> void:
	preload("res://scripts/recovery_rules.gd").player_reset(self)
	matches.clear()
	state = ""
	remaining = 0
	freeze = 0
	height = 0
	velocity = 0
	rebound = false
	knockdown = false
	float_pose_index = 2
	float_launch_speed = 1
	chain_count = 0
	chain_last_ms = 0
	chain_guard_until = 0
	movement.reset()
	if reset_player and is_instance_valid(run):
		run.player.reset_jump()
		run.player.action_locked = false
	release_clock()


func motion_frames(id: int) -> Array:
	var career: Dictionary = data.get("motions", {})
	var by_id: Dictionary = career.get(str(Game.base_career()), {})
	var motion: Dictionary = by_id.get(str(id), {})
	return motion.get("frames", [])


func play_motion(id: int, index: int = 0) -> void:
	matches.clear()
	var frames: Array = motion_frames(id)
	if frames.is_empty():
		return
	movie.configure(frames)
	movie.timeline.goto_frame(index)
	run.player.get_node("Visual").begin_action_motion(id, index)
	owns_clock = true
	movie.advance()


# 收尾统一出口：把 Visual 的外部时钟摘掉，交回给 player/ 普通动画。
# 老实现只改 state/action_locked，时钟一直开着 → avatar_view._process 每帧 early return，
# 画面停在受击/倒地那一帧，人又不能动，看起来就是「技能动画卡死」。
func release_clock() -> void:
	if not owns_clock:
		return
	owns_clock = false
	if not is_instance_valid(run) or not is_instance_valid(run.player):
		return
	var vis = run.player.get_node_or_null("Visual")
	if vis == null:
		return
	vis.end_action_motion()
	if not run.player.jumping:
		vis.set_motion(3, vis.facing_left)


func begin_lie() -> void:
	preload("res://scripts/recovery_rules.gd").player_lie(self)


func hold_position() -> void:
	var delta: Vector2 = movement.advance(run.player.position) - run.player.position
	if delta != Vector2.ZERO:
		run.player.move_and_collide(delta)


func handle_hit(damage: int, hit: Dictionary, direction: int) -> bool:
	if is_instance_valid(run) and run.has_meta("jjxf_fatal_pending"):
		return true
	if not is_instance_valid(run) or run.status != "battle":
		return false
	var knock_hits = preload("res://scripts/knockdown_hits.gd")
	if knock_hits.downed(run):
		if knock_hits.allowed(int(hit.get("skill", 0))):
			knock_hits.strike(run, damage)
		return true
	if run.invincible > 0 or run.source_status.has_class(11):
		return false
	if preload("res://scripts/recovery_rules.gd").player_protected(run):
		return false
	if preload("res://scripts/block_rules.gd").protects_hit(run, hit):
		preload("res://scripts/block_rules.gd").refresh(run)
		run.hurt_player(damage)
		if run.status == "defeat":
			reset()
			run.player.action_locked = true
		return true
	run.hurt_player(damage)
	if run.status == "defeat":
		reset()
		run.player.action_locked = true
		return true
	# 技能施法 1 秒内的隐藏霸体（不显示特效）：伤害上面已经照吃，
	# 只是不再进入受击硬直/浮空，所以技能不会被打断。
	if run.has_method("skill_guard_active") and run.skill_guard_active():
		run.record("skill_guard", {"damage": damage})
		return true
	# 连击计数：5 秒内连续挨打才算一套，超过上限就触发保护。
	var now_ms: int = Time.get_ticks_msec()
	if now_ms - chain_last_ms > CHAIN_RESET_MS:
		chain_count = 0
	chain_last_ms = now_ms
	chain_count += 1
	if chain_count > CHAIN_LIMIT and now_ms >= chain_guard_until:
		chain_guard_until = now_ms + CHAIN_GUARD_MS
		force_recover()
		return true
	accept(hit, direction)
	return true


# 触发保护时把玩家从浮空/受击状态拉回地面，走正常倒地→起身流程。
func force_recover() -> void :
	velocity = 0
	height = 0
	freeze = 0
	var recovery = preload("res://scripts/recovery_rules.gd")
	if state in ["lie", "get_up"]:
		remaining = mini(remaining, 2)
	else:
		recovery.player_lie(self)
	render_height()
	run.record("chain_guard", {"chain": chain_count})


func accept(hit: Dictionary, direction: int) -> void:
	# 连击保护窗口内：伤害在 handle_hit 里已经结算，这里一律不再进硬直/浮空/倒地。
	if Time.get_ticks_msec() < chain_guard_until:
		return
	if preload("res://scripts/block_rules.gd").protects_hit(run, hit):
		return
	if state in ["lie", "get_up"]:
		return
	var model: Dictionary = run.source_status.model({"holdFlag": 0, "holdXRate": 1.0, "beHurtFloat": 1, "beHurtBack": 1})
	if int(model.holdFlag) > int(hit.get("attack_type", 0)):
		movement.execute({"x": int(int(hit.get("power_x", 0)) * float(model.holdXRate) * float(model.beHurtBack))}, direction, {}, 0)
		return
	var already_float: bool = state == "float"
	var was_airborne: bool = run.player.jump_height > 0
	var power: int = int(hit.get("air_power_y", 0)) if was_airborne else int(hit.get("power_y", 0))
	var threshold: int = int(rules.get("knockdown_air_power_y", 1000)) if was_airborne else int(rules.get("knockdown_power_y", 2000))
	height = run.player.jump_height
	if run.action_player.active:
		run.action_player.stop()
	elif not already_float:
		run.finish_action(-1)
	# 只 stop 不够：current_skill / blocking_rate 会残留，之后每次挨打都被
	# damage_calculator 判成「背击破招」多吃 25%，格挡减伤也一直挂着，
	# 表现为「实际掉血和弹字对不上、越打越疼」。
	if int(run.current_skill) != 0 or float(run.blocking_rate) > 0.0:
		run.finish_action(-1)
	run.clear_action_inputs()
	# 二次受击时 reset_jump() 会 end_action_motion，浮空外部时钟就丢了。
	if not already_float:
		run.player.reset_jump()
	run.player.clear_direction_cache()
	run.player.action_locked = true
	movement.reset()
	freeze = int(hit.get("freeze", 0))
	knockdown = power >= threshold
	if knockdown or was_airborne:
		velocity = power
		state = "float"
		# A mid-air hit uses the descending picture without restarting motion 12.
		if already_float:
			float_pose_index = 4
		else:
			float_launch_speed = maxi(1, absi(velocity))
			float_pose_index = 2
			play_motion(12, 2)
		if height == 0 and velocity <= 0:
			begin_lie()
	else:
		state = "hurt"
		remaining = maxi(4, int(rules.get("hurt_ticks", 8)))
		play_motion(11)
		movie.timeline.playing = false
	movement.execute({"x": preload("res://scripts/recovery_rules.gd").recoil_power(hit, was_airborne, model)}, direction, {}, 0)
	if state == "float":
		hold_float_pose()
	render_height()
	run.record("player_reaction", {"state": state, "power_y": power, "knockdown": knockdown, "direction": direction})


func advance() -> void:
	hold_float_pose()
	preload("res://scripts/block_rules.gd").refresh(run)
	preload("res://scripts/armor_glow.gd").refresh_player(run)
	if preload("res://scripts/recovery_rules.gd").player_advance(self):
		return
	if state.is_empty():
		hold_position()
		return
	if freeze > 0:
		freeze -= 1
		return
	hold_position()
	var packet: Dictionary = {}
	if state == "float":
		height = maxi(0, int(height + velocity * 0.01))
		if height == 0:
			if not knockdown:
				finish()
				return
			if not rebound:
				rebound = true
				float_pose_index = 4
				velocity = int(-velocity * (0.3 + run.combat_random.next_float() * 0.1))
				movie.timeline.goto_frame(3)
				movie.timeline.playing = false
				hold_float_pose()
				movement.reset()
				var land_sound: int = int(Game.presentation_data.audio.definitions.landSound)
				if land_sound != 0:
					run.world.audio.play_package(land_sound)
			else:
				begin_lie()
				return
		else:
			var rising: bool = velocity > 0
			velocity += int(run.reaction_data.gravity)
			if rising and velocity <= 0:
				velocity = 0
		advance_float_pose()
		packet = movie.advance()
	elif state == "hurt":
		remaining -= 1
		if remaining <= 0:
			finish()
			return
	render_height()


func finish() -> void:
	reset()
	run.player.get_node("Visual").set_motion(3, run.player.get_node("Visual").facing_left)


func render_height() -> void:
	run.player.jump_height = height
	run.player.get_node("Visual").position.y = -height
	run.player.get_node("Name").position.y = -run.player.visual_height - 26 - height
	run.player.get_node("Shadow").scale = Vector2.ONE * clampf(1 - height / 200.0, 0.45, 1)
