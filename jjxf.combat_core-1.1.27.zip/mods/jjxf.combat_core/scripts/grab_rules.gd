extends RefCounted

# 抓取规则：默认所有怪物（含 boss）都可以被抓取。
# data/catch_immunity.json 可按怪物 id 或出怪包 rank 排除个别目标。

const PATH: String = "res://data/catch_immunity.json"

static var _rules: Dictionary = {}
static var _loaded: bool = false


static func _table() -> Dictionary:
	if not _loaded:
		_loaded = true
		if FileAccess.file_exists(PATH):
			var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
			if parsed is Dictionary:
				_rules = parsed
	return _rules


static func monster_rank(monster) -> int:
	if monster == null:
		return 0
	return int(monster.get_meta("drop_rank", int(monster.spec.get("rank", 0))))


static func _in_list(values, needle: String) -> bool:
	if values is Array:
		for value in values:
			if str(int(value)) == needle:
				return true
	return false


static func allows(rules: Dictionary, monster) -> bool:
	if monster == null or not is_instance_valid(monster):
		return false
	if rules.is_empty():
		return true
	if _in_list(rules.get("immune_monster_ids", []), str(int(monster.monster_id))):
		return false
	if _in_list(rules.get("immune_ranks", []), str(monster_rank(monster))):
		return false
	return true


static func can_catch(monster) -> bool:
	if monster == null or not is_instance_valid(monster):
		return false
	if preload("res://scripts/boss_traits.gd").no_grab(monster):
		return false
	return allows(_table(), monster)


# A successful mind-eye grab owns the target's action, even for a boss whose
# incoming damage normally preserves its attack or knockdown recovery.
static func begin_catch(run, monster) -> void:
	if run == null or int(Game.role().get("career", 0)) != 330 or monster == null or not is_instance_valid(monster) or monster.dead:
		return
	# Reuse the same policy as whirlwind's second stage; training armor also applies.
	if not can_catch(monster) or not monster.can_be_caught():
		return
	monster.cancel_attack()
	monster.stun = 0
	monster.impact_freeze = 0
	monster.lie_ticks = 0
	monster.getting_up = false
	monster.rebound = false
	monster.airborne = false
	monster.air_velocity = 0
	monster.reaction_player.timeline.playing = false
	monster.script_movement.reset()
	monster.animation_frame_ref = -1
	monster.set_motion("13")

# Some grabs hit on their setup frame (notably the aerial hammer). Install
# the catch/branch before that hit consumes its once-per-target quota.
static func prepare_catch_frame(run, packet: Dictionary) -> void:
	if run == null or int(Game.role().get("career", 0)) != 330 or int(run.current_skill) == 0 or not run.action_player.active or int(run.action_player.state_index) != 0 or str(packet.get("event", "")) != "hit":
		return
	var scripts: Array = packet.get("scripts", [])
	if not scripts.any(func(script):return str(script.cmd) == "catchTarget" and int(script.args.get("argStr", 0)) > 0):
		return
	var retained: Array = []
	for script in scripts:
		if str(script.cmd) in ["catchTarget", "hitScript"]:
			run.play_frame_script(str(script.cmd), script.args)
		else:
			retained.append(script)
	packet.scripts = retained


# Player feedback fixes, applied after all combat catalogs have merged.
static func apply_feedback(combat: Dictionary) -> int:
	var changed: int = 0
	for id in combat.catalog:
		var spec: Dictionary = combat.catalog[id]
		var action: int = int(spec.action)
		if int(spec.career) == 120 and action in [129, 130]:
			var parent: Dictionary = combat.catalog.get(str(12100 + clampi(int(id) % 100, 1, 30)), combat.catalog["12101"])
			spec.cooldown = int(parent.cooldown)
			spec.start_cd = int(parent.start_cd)
			changed += 1
		if int(spec.career) == 130 and action in [131, 132, 145]:
			for hit in spec.hits:
				hit.interval = 30
				hit.multiple = 10000
			changed += 1
	var sword: Dictionary = combat.career_motions["100"]["121"]
	sword.frames[5].ticks = 9
	for script in sword.frames[5].scripts:
		if str(script.cmd) == "acceptVKey":script.args.limitFrames = "9"
	retime(sword)
	# A close enemy pressed against a wall must remain in the stomp's contact box.
	for motion_id in [206, 210]:
		for frame in combat.career_motions["200"][str(motion_id)].frames:
			if str(frame.event) != "hit":continue
			for area in frame.areas:
				if str(area.type) == "ac" and float(area.x) > -25:
					area.w = str(float(area.w) + float(area.x) + 25)
					area.x = "-25"
	var spin: Dictionary = combat.career_motions["300"]["304"]
	for frame in spin.frames:
		if str(frame.event) == "hit":
			frame.areas = [{"type":"ac","x":"-125","y":"-160","w":"250","h":"180","dz":"65"}]
	# The second aerial followup used stop=-1, which disabled gravity for nine ticks.
	var aerial: Dictionary = combat.career_motions["300"]["306"]
	for index in [12, 13]:
		for script in aerial.frames[index].scripts:
			if str(script.cmd) == "move":
				script.args.stop = "0"
				script.args.y = "-900"
				script.args.gRate = "1.5"
	aerial.frames[13].ticks = 2
	retime(aerial)
	var wheel: Dictionary = combat.career_motions["300"]["330"]
	wheel.frames[1].ticks = 30
	for frame in wheel.frames:
		for script in frame.scripts:
			if str(script.cmd) == "createEffect" and int(script.args.get("id", 0)) in [33001,33002,33003,33004]:script.args.bind = "1"
	retime(wheel)
	changed += apply_awake_followup(combat)
	return changed

static func retime(motion: Dictionary) -> void:
	var tick: int = 0
	for frame in motion.frames:
		frame.tick = tick
		tick += int(frame.ticks)
	motion.duration = tick

static func action_of(run) -> int:
	return int(Game.slice_data.skills.get(str(int(run.current_skill)), {}).get("action", 0))

static func held_target(run, monster, skill: int) -> bool:
	return int(Game.role().get("career",0)) == 330 and skill == int(run.current_skill) and monster.caught and monster in run.caught_targets

static func caught_contact(run, monster, skill: int) -> bool:
	# Includes the gunner's airborne sweeping shots: their victim can be clamped
	# behind the muzzle by a wall. Ownership of a live catch is authoritative.
	return skill == int(run.current_skill) and monster.caught and monster in run.caught_targets and (held_target(run,monster,skill) or action_of(run) == 210)

static func bound_height(run, height: int) -> int:
	return int(round(height * 0.6)) if int(Game.role().get("career",0)) == 330 else height

static func feedback_stage(run, index: int) -> void:
	awake_catch_group(run,index)
	if index == 0:
		run.set_meta("feedback_damage", {})
		for key in ["normal_attack_buffer", "flame_branch_buffer"]:
			if run.has_meta(key):run.remove_meta(key)

static func remember_damage(run, monster, skill: int, amount: int) -> void:
	if skill != int(run.current_skill) or action_of(run) not in [327,328] or int(Game.role().get("career",0)) != 330:return
	var damage: Dictionary = run.get_meta("feedback_damage", {})
	var id: int = monster.get_instance_id()
	damage[id] = int(damage.get(id,0)) + amount
	run.set_meta("feedback_damage", damage)

static func buffer_input(run, key: int, pressed: bool) -> void:
	if not pressed or not run.action_player.active:return
	if key >= 1000:key %= 1000
	var action: int = action_of(run)
	if action == 4 and key == 11:
		run.set_meta("normal_attack_buffer", {"until":int(run.ticks)+8,"state":int(run.combo)})
	if action == 121 and key in [11,13] and (bool(run.action_player.held.get(2,false)) or bool(run.action_player.held.get(3,false))):
		run.set_meta("flame_branch_buffer", {"until":int(run.ticks)+9,"vkey":130000 if key == 11 else 129000})

static func feedback_aux(run) -> void:
	awake_aux(run)
	var action: int = action_of(run)
	if run.has_meta("normal_attack_buffer"):
		var buffer: Dictionary = run.get_meta("normal_attack_buffer")
		if action != 4 or int(buffer.state) != int(run.combo) or int(buffer.until) < int(run.ticks):
			run.remove_meta("normal_attack_buffer")
		elif not run.action_player.matches.is_empty():
			run.remove_meta("normal_attack_buffer")
			var was_held: bool = bool(run.action_player.held.get(11,false))
			run.action_player.input_vkey(11)
			run.action_player.held[11] = was_held
	if run.has_meta("flame_branch_buffer"):
		var buffer: Dictionary = run.get_meta("flame_branch_buffer")
		if action != 121 or int(buffer.until) < int(run.ticks):
			run.remove_meta("flame_branch_buffer")
		elif int(run.action_player.timeline.frame_index) >= 5:
			run.remove_meta("flame_branch_buffer")
			var id: int = int(buffer.vkey) / 1000 * 100 + 1
			if not preload("res://scripts/recovery_rules.gd").reject_cooldown(run,id):run.action_player.stop(int(buffer.vkey))
	if action == 330 and int(Game.role().get("career",0)) == 330 and int(run.combo) == 0:
		var facing: int = int(run.action_player.facing)
		var destination: Vector2 = run.player.position + Vector2(65*facing,0)
		for monster in run.monsters:
			if not is_instance_valid(monster) or monster.dead or monster.caught or not monster.can_be_caught():continue
			var relative: Vector2 = monster.position - run.player.position
			if relative.x*facing < -20 or relative.x*facing > 500 or absf(relative.y)>100:continue
			var step: Vector2 = destination - monster.position
			step.x = clampf(step.x,-14,14)
			step.y = clampf(step.y,-4,4)
			monster.move_and_collide(step)

static func spinning_control(run) -> bool:
	var action: int = action_of(run)
	if int(Game.base_career()) != 300 or action not in [304,328] or run.control_args.is_empty():return false
	var held: Dictionary = run.action_player.held
	var x: int = int(Input.is_action_pressed("move_right") or bool(held.get(3,false))) - int(Input.is_action_pressed("move_left") or bool(held.get(2,false)))
	var z: int = int(Input.is_action_pressed("move_down") or bool(held.get(1,false))) - int(Input.is_action_pressed("move_up") or bool(held.get(0,false)))
	var rate: float = float(run.control_args.get("speedRate",1))
	run.player.move_and_collide(Vector2(x,z*float(run.control_args.get("zRate",1))) * float(run.player.movement_speed)/30.0*rate)
	if x != 0:
		run.action_player.facing = x
		run.player.get_node("Visual").facing_left = x<0
	return true

static func field_hit(interact, collision: Dictionary, contacts: Array) -> int:
	var quota: Dictionary = interact.hits
	var last: Dictionary = interact.last_hits
	if not interact.hostile and int(interact.spec.get("id",0)) in [70001,70011,75002]:
		quota = interact.get_meta("magnetic_pulse_quota", {})
		last = interact.get_meta("magnetic_pulse_clock", {})
		interact.set_meta("magnetic_pulse_quota",quota)
		interact.set_meta("magnetic_pulse_clock",last)
	return interact.run.hit_monsters(collision,interact.skill_id,interact.skill_index,interact.position,interact.height,interact.facing,quota,last,interact.attack_model,contacts)

static func reference_distance(run, action: int) -> float:
	var clock = preload("res://scripts/flash/action_player.gd").new()
	var movement = preload("res://scripts/flash/script_movement.gd").new()
	var queued: Dictionary = {"catch":false}
	clock.configure(Game.flash_actions,Game.slice_data.motions)
	var on_script: Callable = func(command,args):
		if command == "move":movement.execute(args,1,{},0)
	var on_hit: Callable = func(event,_frame):
		if action == 347 and clock.state_index == 0 and event == "hit":queued.catch=true
	clock.script_requested.connect(on_script)
	clock.frame_event.connect(on_hit)
	clock.begin(330,action,int(run.combat_attack_speed()))
	var position: Vector2 = Vector2.ZERO
	for tick in range(300):
		if not clock.active:break
		if bool(queued.catch):
			queued.catch=false
			clock.set_state(1)
		position = movement.advance(position)
		clock.advance()
	clock.script_requested.disconnect(on_script)
	clock.frame_event.disconnect(on_hit)
	return absf(position.x)

static func prepare_throw(run, monster) -> void:
	var action: int = action_of(run)
	if int(Game.role().get("career",0)) != 330 or action not in [327,328]:return
	var distance: float = throw_distance(run,action)
	var total: int = int(run.get_meta("feedback_damage",{}).get(monster.get_instance_id(),0))
	var height: int = int(monster.air_height)
	var velocity: int = int(monster.air_velocity)
	var frames: int = 0
	while frames < 180:
		frames += 1
		height = maxi(0,int(height+velocity*0.01))
		if height == 0:break
		velocity += int(run.reaction_data.gravity)
	monster.set_meta("mindeye_throw",{"from":monster.position,"to":run.player.position+Vector2(distance*run.action_player.facing,0),"frames":frames,"tick":0,"damage":maxi(0,int(round(total*0.15))),"skill":int(run.current_skill)})
	monster.script_movement.reset()

static func throw_step(monster) -> void:
	if not monster.has_meta("mindeye_throw"):return
	if monster.dead or monster.caught:
		monster.remove_meta("mindeye_throw")
		return
	var flight: Dictionary = monster.get_meta("mindeye_throw")
	flight.tick = int(flight.tick)+1
	var destination: Vector2 = Vector2(flight.from).lerp(Vector2(flight.to),minf(1.0,float(flight.tick)/int(flight.frames)))
	monster.move_and_collide(destination-monster.position)
	monster.set_meta("mindeye_throw",flight)

static func landing_damage(monster) -> void:
	if not monster.has_meta("mindeye_throw") or int(monster.air_height)>0:return
	var flight: Dictionary = monster.get_meta("mindeye_throw")
	monster.remove_meta("mindeye_throw")
	if monster.dead or int(flight.damage)<=0:return
	monster.set_meta("damage_skill_id",int(flight.skill))
	monster.set_meta("damage_critical",false)
	monster.damage(int(flight.damage),Vector2.ZERO,false,{"damage_only":true})
	monster.run.record_hit(int(flight.damage))
	monster.run.record("grab_landing_hit",{"skill":int(flight.skill),"damage":int(flight.damage)})


static func apply_awake_followup(combat: Dictionary) -> int:
	var motion: Dictionary = combat.career_motions["300"]["353"]
	# The authored hands start their downward stroke at effect frame 49. The
	# movement script runs after this tick's vertical update, hence 48 hover ticks.
	motion.frames[42].ticks = 48
	for frame in motion.frames:
		for script in frame.scripts:
			if str(script.cmd)=="createEffect" and int(script.args.get("id",0)) in [35301,35306,35311]:
				script.args.bind = "1"
				script.args.follow_visual = "1"
	retime(motion)
	var definitions: Dictionary = preload("res://scripts/flash/skill_status.gd").definitions
	# The combat catalog uses a compact effects-only status. Clone the native
	# event schema, which SkillStatus accepts when rebuilding its definitions.
	var status: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/career_status.json")).statuses["7001"].duplicate(true)
	var interval: int = int(combat.catalog["13101"].hits[0].interval)
	status.attributes.id = "99131050"
	status.attributes.duration = str(maxi(1,int(round(interval*0.8/3.0))))
	combat.statuses["99131050"] = status
	if not definitions.is_empty():definitions.statuses["99131050"] = status
	return 1

static func awake_aux(run) -> void:
	if int(Game.role().get("career",0)) != 330 or action_of(run) != 353:return
	if int(run.combo)==0:
		var frame: Dictionary = Game.career_combat.career_motions["300"]["353"].frames[1]
		for monster in run.monsters:
			if not is_instance_valid(monster) or monster.dead or monster.caught or not monster.can_be_caught() or monster.skill_status.has_class(11):continue
			var delta: Vector2 = monster.position - run.player.position
			var inside: bool = false
			for area in frame.areas:
				if str(area.type)=="ac" and delta.x*run.action_player.facing+20>=float(area.x) and delta.x*run.action_player.facing-20<=float(area.x)+float(area.w) and absf(delta.y)<=float(area.dz)+5:inside=true
			if not inside:continue
			var step: Vector2 = -delta
			step.x=clampf(step.x,-7.0,7.0)
			step.y=clampf(step.y,-3.5,3.5)
			hold_awake_pull(run,monster)
			monster.move_and_collide(step)

static func awake_catch_group(run, index: int) -> void:
	if int(Game.role().get("career",0))!=330 or action_of(run)!=353 or index!=2 or run.caught_targets.is_empty():return
	for monster in run.monsters:
		if run.caught_targets.size()>=50:break
		if not is_instance_valid(monster) or monster.dead or monster.caught or not can_start_catch(run,monster) or monster.skill_status.has_class(11):continue
		var relative: Vector2 = monster.position-run.player.position
		if absf(relative.x)>100 or absf(relative.y)>45:continue
		begin_catch(run,monster)
		monster.caught=true
		run.caught_targets.append(monster)

static func attach_awake_effect(effect, actor, args: Dictionary) -> bool:
	if preload("res://scripts/skill_steer.gd").attach_comet_visual(effect,actor,args):return true
	if preload("res://scripts/skill_steer.gd").attach_phoenix_effect(effect,actor,args):return true
	if int(args.get("follow_visual",0))!=1:return false
	var visual = actor.get_node_or_null("Visual")
	if visual==null:return false
	# The original spawn already multiplies scale/offset by Visual.scale.
	# Parenting to the actual display node supplies that scale and its jump
	# translation automatically, so undo only the previously applied multiplier.
	var art_scale: float = maxf(0.00001,absf(visual.scale.y))
	effect.base_offset /= art_scale
	effect.original_scale /= art_scale
	effect.position = Vector2(effect.base_offset.x*(-1 if effect.left else 1),effect.base_offset.y)
	effect.set_meta("follow_visual",true)
	visual.add_child(effect)
	return true

static func rush_reach(run) -> float:
	var clock = preload("res://scripts/flash/action_player.gd").new()
	var movement = preload("res://scripts/flash/script_movement.gd").new()
	var state: Dictionary = {"position":Vector2.ZERO,"reach":0.0}
	clock.configure(Game.flash_actions,Game.slice_data.motions)
	var on_script: Callable = func(command,args):
		if command=="move":movement.execute(args,1,{},0)
	var on_hit: Callable = func(event,frame):
		if event!="hit":return
		for area in frame.get("areas",[]):
			if str(area.type)=="ac":state.reach=maxf(float(state.reach),Vector2(state.position).x+float(area.x)+float(area.w)+20.0)
	clock.script_requested.connect(on_script)
	clock.frame_event.connect(on_hit)
	clock.begin(330,347,int(run.combat_attack_speed()))
	for tick in range(300):
		if not clock.active:break
		state.position=movement.advance(Vector2(state.position))
		clock.advance()
	clock.script_requested.disconnect(on_script)
	clock.frame_event.disconnect(on_hit)
	return float(state.reach)

static func throw_distance(run, action: int) -> float:
	return reference_distance(run,343)+14.5+58.0*1.5 if action==327 else rush_reach(run)+2.0

# A pull owns movement and the hurt pose only for the current production tick.
# The next stage, an interruption or leaving the area releases it immediately.
const AWAKE_PULL: String = "mindeye_awake_pull"

static func hold_awake_pull(run, monster) -> void:
	var state: Dictionary = monster.get_meta(AWAKE_PULL,{})
	if state.is_empty():
		state={"motion":monster.motion,"frame":monster.animation_frame_ref}
	state.tick=run.ticks
	monster.set_meta(AWAKE_PULL,state)
	monster.cancel_attack()
	monster.set_motion("11")

static func awake_pull_tick(monster) -> bool:
	if not monster.has_meta(AWAKE_PULL):return false
	var state: Dictionary = monster.get_meta(AWAKE_PULL)
	var run=monster.run
	var held: bool = is_instance_valid(run) and int(state.tick)==int(run.ticks) and run.active and run.action_player.active and int(Game.role().get("career",0))==330 and action_of(run)==353 and run.combo==0 and not monster.dead and not monster.caught
	if not held:
		monster.remove_meta(AWAKE_PULL)
		if not monster.dead and not monster.caught and monster.motion=="11":
			if monster.airborne or monster.lie_ticks>0 or monster.getting_up:
				monster.set_motion(str(state.motion))
				monster.animation_frame_ref=int(state.frame)
			else:
				monster.set_motion("11" if monster.stun>0 else "3")
		return false
	# Run this before AI, recovery and scripted/air movement. Damage/status clocks
	# still advance normally; the attraction itself never adds extra damage.
	monster.advance_source_statuses()
	if monster.dead:
		monster.remove_meta(AWAKE_PULL)
		return false
	preload("res://scripts/armor_glow.gd").refresh_monster(monster)
	if monster.attack_tick>=0:monster.cancel_attack()
	monster.set_motion("11")
	monster.animation_frame_ref=-1
	monster.animation_tick+=1
	monster.render_frame()
	return true

# Evaluate the ground state BEFORE a starter hit can change the reaction state.
static func can_start_catch(run, monster) -> bool:
	if not monster.can_be_caught():return false
	if int(Game.role().get("career",0))!=330 or action_of(run)==347:return true
	return monster.caught or not (monster.lie_ticks>0 or monster.getting_up)

const GRAB_POSE: String = "mindeye_grab_pose"
const GRAB_REFLECTION: String = "mindeye_grab_reflection"

static func grab_pose(monster) -> Dictionary:
	var run=monster.run
	if not is_instance_valid(run) or not monster.caught or monster.dead or monster not in run.caught_targets:return {}
	if int(Game.role().get("career",0))==110 and action_of(run)==116 and int(run.combo)==1:
		return {"motion":"15","frame":1,"invert":false}
	if int(Game.role().get("career",0))!=330:return {}
	var action: int = action_of(run)
	if action not in [327,329,330,335,350]:return {}
	var frame: int = int(run.action_player.timeline.frame_index)
	var down: bool = (action==329 and frame>=6 and frame<=10) or (action==335 and frame>=5 and frame<=25)
	var invert: bool = (action==327 and frame in [6,7,8,12,13,14,15,18,19]) or (action==330 and frame in [6,7,8,11,12,15,16,17,20,21,22,23,24]) or (action==350 and frame>=15 and frame<=18)
	return {"motion":"15" if down else "13","frame":1 if down else -1,"invert":invert}

static func restore_grab_reflection(monster) -> void:
	if not monster.has_meta(GRAB_REFLECTION):return
	for saved in monster.get_meta(GRAB_REFLECTION):
		if is_instance_valid(saved.sprite):saved.sprite.transform=saved.transform
	monster.remove_meta(GRAB_REFLECTION)

static func clear_grab_pose(monster) -> void:
	if not is_instance_valid(monster):return
	restore_grab_reflection(monster)
	if not monster.has_meta(GRAB_POSE):return
	monster.remove_meta(GRAB_POSE)
	monster.animation_frame_ref=-1
	if not monster.dead and monster.motion in ["13","15"] and not (monster.lie_ticks>0 or monster.getting_up):
		monster.set_motion("12" if monster.airborne else ("11" if monster.stun>0 else "3"))

static func prepare_grab_render(monster) -> void:
	restore_grab_reflection(monster)
	var pose: Dictionary = grab_pose(monster)
	if pose.is_empty():
		clear_grab_pose(monster)
		return
	monster.set_meta(GRAB_POSE,true)
	monster.set_motion(str(pose.motion))
	monster.animation_frame_ref=int(pose.frame)

static func finish_grab_render(monster) -> void:
	var pose: Dictionary = grab_pose(monster)
	if pose.is_empty() or not bool(pose.invert):return
	# Reflect only the body layers, around their shared visible center. Labels,
	# ground coordinates, facing, collision and the hold point remain unchanged.
	var bounds: Rect2 = Rect2()
	var saved: Array = []
	for layer in monster.layers:
		var sprite=layer.sprite
		if not is_instance_valid(sprite) or not sprite.visible or sprite.texture==null:continue
		var rect: Rect2 = sprite.transform*sprite.get_rect()
		bounds=rect if saved.is_empty() else bounds.merge(rect)
		saved.append({"sprite":sprite,"transform":sprite.transform})
	if saved.is_empty():return
	var reflection: Transform2D = Transform2D(Vector2.RIGHT,Vector2.UP,Vector2(0,bounds.get_center().y*2))
	for item in saved:item.sprite.transform=reflection*item.transform
	monster.set_meta(GRAB_REFLECTION,saved)
