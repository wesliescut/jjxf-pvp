extends RefCounted

# 技能前向位移表：按“基础职业:动作号”覆盖动作帧里 move 脚本的水平速度。
# 基础职业用 Game.base_career() 归一，因此天剑的所有转职共用同一份配置。

const PATH: String = "res://data/skill_forward.json"

static var _moves: Dictionary = {}
static var _loaded: bool = false


static func _table() -> Dictionary:
	if not _loaded:
		_loaded = true
		if FileAccess.file_exists(PATH):
			var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
			if parsed is Dictionary:
				_moves = parsed.get("moves", {})
	return _moves


static func adjust(motion_id: int, args: Dictionary) -> Dictionary:
	if int(args.get("stop", 0)) == 1:
		return args
	if int(args.get("x", 0)) == 0:
		return args
	var entry = _table().get("%d:%d" % [Game.base_career(), motion_id])
	if entry == null:
		return args
	args["x"] = str(int(entry.get("forward_x", args.get("x", 0))))
	return args
