extends Node


func install(_api) -> bool:
	return true


func _well_formed(row, width: int) -> bool:
	# JSON 取出来的数字是 float，这里只判结构：长度对、都是非负数。
	if not (row is Array) or (row as Array).size() != width:
		return false
	var values: Array = row
	for value in values:
		if int(value) < 0:
			return false
	return true


func verify(_api) -> Dictionary:
	# 只做结构自检：这张表允许被「掉落率-ALT高爆版」整文件接管，
	# 所以不能把 44/35/15/3/2 写死成唯一合法值，否则一开 ALT 就误报。
	var parsed = JSON.parse_string(FileAccess.get_file_as_string("res://data/dungeon_loot.json"))
	if not (parsed is Dictionary):
		return {"ok": false, "reason": "dungeon_loot.json 读取失败"}
	var data: Dictionary = parsed
	var rw: Dictionary = data.get("rarity_weights", {})
	var brw: Dictionary = data.get("boss_rarity_weights", {})
	var galaxy: Array = data.get("galaxy_weapons", [])
	var ok: bool = (_well_formed(rw.get("1"), 5) and _well_formed(rw.get("11"), 5)
		and _well_formed(rw.get("20"), 5) and _well_formed(brw.get("20"), 5)
		and galaxy.size() > 0)
	return {"ok": ok, "rarity_1": rw.get("1"), "rarity_20": rw.get("20"), "galaxy_count": galaxy.size()}
