基于 1.1.17。练习场使用独立的 training_player_reaction.gd，先前版本主要修改副本 player_hit_reaction.gd。本版把练习场击飞时的横向帧、外部动作时钟和动作锁定与副本对齐，并让 guard_stuck_action 同时识别练习场受击状态，避免空中解除锁定后可移动。保留原版敌人数值、本职业装备掉落和经验 1/3/5。未做游戏内战斗验证。
